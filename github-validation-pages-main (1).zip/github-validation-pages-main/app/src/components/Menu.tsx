import React from "react";
import RunResult from "../types/ResultTypes";
import MenuTile from "./MenuTile";
import "./Menu.css"

export default class Menu extends React.Component<{
    testResults: RunResult[] | null,
    testResult: RunResult | null
}> {
    getTestResults = () =>
        this.props.testResults === null ? <></> : this.props.testResults.map((r: RunResult) =>
            <MenuTile key={r.stats.title} runResult={r} selected={r.stats.title === this.props.testResult?.stats.title}></MenuTile>);

    render = () => <><div className="menu">{this.getTestResults()}</div><div className="clear"></div></>;
}