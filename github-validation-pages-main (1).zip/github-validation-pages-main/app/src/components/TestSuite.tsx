import * as React from "react"
import TestCase from "./TestCase";
import Pill from "./Pill"
import { SuiteResult, TestCaseResult } from "../types/ResultTypes";

export default class TestSuite extends React.Component<{ suite: SuiteResult, level: number }> {
    getSuites = () =>
        this.props.suite.suites.map((s: SuiteResult) =>
            <TestSuite key={s.title} suite={s} level={1} />);

    getTests = () =>
        this.props.suite.tests.map((t: TestCaseResult) =>
            <TestCase key={t.uuid} test={t} />);

    getPrefix = () => this.props.level === 0 ? "Component" : (this.props.level === 1 ? "Case" : "Suite");

    render = () => <>
        {this.props.level === 0 ?
            <h2><Pill skipped={this.props.suite.skipped.length > 0} fail={this.props.suite.failures.length > 0}>{this.getPrefix()}:</Pill> {this.props.suite.title}</h2> :
            <h3><Pill skipped={this.props.suite.skipped.length > 0} fail={this.props.suite.failures.length > 0}>{this.getPrefix()}:</Pill> {this.props.suite.title}</h3>}
        <blockquote>{this.getSuites()}
            {this.getTests()}</blockquote></>
}