import * as React from "react"
import Pill from "./Pill"
import Code from "./Code"
import { TestCaseResult } from "../types/ResultTypes";

export default class TestCase extends React.Component<{ test: TestCaseResult }> {
    render = () => <>
        <h4><Pill skipped={this.props.test.skipped} fail={this.props.test.fail}>Test:</Pill> {this.props.test.title}</h4>
        <p>{this.props.test.fullTitle}</p>
        <table width={"100%"}>
            <thead>
                <tr>
                    <th>Property</th>
                    <th>Value</th>
                </tr>
            </thead>
            <tbody>
                {this.props.test.timedOut &&
                    <tr>
                        <td><strong>timedOut</strong></td>
                        <td>{this.props.test.timedOut}</td>
                    </tr>}
                <tr>
                    <td><strong>duration</strong></td>
                    <td>{this.props.test.duration}</td>
                </tr>
                {this.props.test.state &&
                    <tr>
                        <td><strong>state</strong></td>
                        <td>{this.props.test.state}</td>
                    </tr>}
                {this.props.test.speed &&
                    <tr>
                        <td><strong>speed</strong></td>
                        <td>{this.props.test.speed}</td>
                    </tr>}
                {this.props.test.pending &&
                    <tr>
                        <td><strong>pending</strong></td>
                        <td>{this.props.test.pending}</td>
                    </tr>}
                {this.props.test.skipped &&
                    <tr>
                        <td><strong>skipped</strong></td>
                        <td>{this.props.test.skipped}</td>
                    </tr>}
            </tbody>
        </table>
        {!!this.props.test.code &&
            <>
                <h5>Test Code</h5>
                <Code>{this.props.test.code}</Code>
            </>}
    </>
}