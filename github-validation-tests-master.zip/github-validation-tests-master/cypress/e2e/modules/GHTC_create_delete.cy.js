// Module declarations
import {GH_visit} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import * as constants from '../modules/Constants.cy.js';
 
export function GH_delete_repo(org, repo) {
     GH_visit(constants.BASEURL+'/'+org+'/'+repo);
	 
     // select Settings tab option 
     GH_settings_tab(org, repo);

     // select option to delete.....and confirm
     cy.contains('Delete this repository').should('be.visible').click();
     cy.get('.Box-body > form > p > .form-control').should('be.visible').type(org+'/'+repo);
     cy.get('.Box-body > form > .btn').should('be.visible').click();
}

export function GH_create_repo(org, repo) {
     // go to home organisation 
     GH_visit(constants.BASEURL+'/'+org);
     constants.GH_screenshot('GH_create_repo (1) : organization view');

     // click on repositories tab
     cy.get('[data-tab-item="org-header-repositories-tab"]').should('be.visible').click();
     cy.url().should('include', '/repositories');
	
     constants.GH_screenshot('GH_create_repo (2) : repositories view');

     //click on new repositories button and enter name
     cy.reload();
     cy.get('.d-md-flex > .btn').should('be.visible').click();

     // not really neccessary but still ...........
     GH_visit('https://github.com/organizations/'+org+'/repositories/new');
     cy.get('#repository_name').should('be.visible').type(repo); 
     //constants.GH_screenshot('GH_create_repo (3): new repo selected');
	
     // select private and readme file 
     cy.get('#repository_visibility_public').should('be.visible').click();
     cy.get('#repository_auto_init').should('be.visible').click();
     constants.GH_screenshot('GH_create_repo (3): select private and readme');

     // and create
     cy.contains('Create repository').should('be.visible').click();
     constants.GH_screenshot('GH_create_repo (4): repo created');
}
 
export function GH_delete_if_exists(org, repo) {
     const ghurl=constants.BASEURL+'/'+org+'/'+repo;
     cy.request({url: ghurl, failOnStatusCode: false}).then((response) => {
       if (response.status === 404) {
             cy.log('==> repo does not exists');
       }
       else {
           cy.log('==> repo does exists');
               GH_delete_repo(org, repo);
       }
     });
  }
 
