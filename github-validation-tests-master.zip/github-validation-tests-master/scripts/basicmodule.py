import lxml.etree as ET
from datetime import datetime
import subprocess
import os
import shutil
import os.path
from os import path
import stat
import json, xmltodict

from tests import workflow
from tests import ghtchttps
from tests import submodule
from tests import wit
from tests import symlink
from tests import testsetup
from tests import settings
from tests.symlink import SymlinkTest
from tests.ghtchttps import httpsTest


# status of test cases:
#    atmic: complete
#    workflow: complete
#    gthttps: complete
#    submodule: Update submodule is still missing. Cleaning up of submodule after testcase?
#    wit: the template misses the last step... I have not implemented neither yet
#    And there are some tests still completely missing: LFS, symlink
#
# TODO: return status of each test case to this module to create a status of all test cases

def getGitVersion():
    try:
        with subprocess.Popen("git --version", shell=True, stdout=subprocess.PIPE,  stderr=subprocess.STDOUT) as p:
            output, errors = p.communicate()
            lines = output.decode('utf-8')
            return [lines]
    except:
        return ["Git version undefined"]
        

        
if __name__ == '__main__':
    print("Set variable that sets the output directory")
    save_path_file = os.path.join(settings.Settings.REPORTDIR,"pythontests.xml")
    print("Start setup of test environment (directory clean up)")
    testsetup.TestTooling.GHSetup()
    print("Check git version")
    print(getGitVersion())
    
    print("Initialize XML document to store test execution details")
    root = ET.Element('testexecution')
    print("Create sub-element 'tests' in XML document")
    tests = ET.SubElement(root,'tests')
    print("Create sub-element 'execution' in XML document")
    execution = ET.SubElement(root,'execution')
    
    print("Store start time of execution to measure test execution duration")
        
    startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    print("===> Workflow - GH_TC_5")
    retWorkflow = workflow.WorkflowTest.testWorkflow(tests)
    print("return value Workflow ",retWorkflow);
    
    print("===> HTTPS - GH_TC_4")
    retHttps = httpsTest.testHttps(tests)
    print("return value Https ",retHttps);
    
    print("===> SYMLINK - GH_TC_8")
    retSymLink = SymlinkTest.testSymlink(tests)
    print("return value Symlink ",retSymLink);
    
    #print("===> testWit")
    #retWit = wit.WitTest.testWit(tests)  
    #print("return value WIT ",retWit);
    
    print("===> Submodules - GT_TC_11")
    retSubmodule = submodule.SubmoduleTest.testSubmodules(tests)
    print("return value Submodules ",retSubmodule);
    
    endTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    execution.set('comment','Created by test script')
    execution.set('starttime',startTime)
    execution.set('endtime',endTime)
    
    xmlOutput = ET.tostring(root, pretty_print=True)
    myfile = open(save_path_file,'wb')
    myfile.write(xmlOutput)
    myfile.close()
    print(xmlOutput)
    
    # now lets add the declarations
    f = open(save_path_file, "r")
    contents = f.readlines()
    f.close()
    
    declaration = '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="htmlstyle.xsl"?>'

    contents.insert(0, declaration)
    
    print("Create handle for file to save XML data");
    f = open(save_path_file, "w")
    print("Prepare content");
    contents = "".join(contents)
    print("Save XML document with test execution");
    print(save_path_file);
    f.write(contents)
    print("Closing file");
    f.close()
    
    # now copy the XSL and the css file to the output directory
    if False:
        # copy it to a different directory if the reports folder si not the one used in the runner
        print("Saving stylesheet and xsl")
        xsltfile = os.path.dirname(os.path.realpath(__file__)) + "/reporter/htmlstyle.xsl"
        shutil.copy(xsltfile, settings.Settings.REPORTDIR)
        cssfile = os.path.dirname(os.path.realpath(__file__)) + "/reporter/webstyle.css"
        shutil.copy(cssfile, settings.Settings.REPORTDIR)
        print("Execution completed successfully. No failed test was reported.")
    
    # convert XML to JSON for Monitoring Dashboard
    o = xmltodict.parse(xmlOutput)
    save_path_json_file = os.path.join(settings.Settings.REPORTDIR,"pythontests.json")
    print("============>>> Saving JSON output to ",save_path_json_file)
    jsonfile = open(save_path_json_file,'w')
    jsonfile.write(json.dumps(o))
    jsonfile.close()

    print("Execution ended")
    
    print("============>>> Let's cleanup ")
    testsetup.TestTooling.GHcleanup()

    #statusOfAllTests = retWorkflow & retHttps & retSymLink # & retSubmodule
    statusOfAllTests = retSubmodule
    if statusOfAllTests:
        # exit(0) means successful run
        exit(0)
    else:
        # exit(1) will result in a failed run
        exit(1)
