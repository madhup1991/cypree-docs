'''
Created on 23.03.2021

@author: dep03990
'''

import os
import lxml.etree as ET
import shutil
from datetime import datetime
#import os.path
#from os import path

from tests import settings
from tests import testsetup
from tests import utilities

class httpsTest(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    
    @classmethod 
    def testHttps(cls,xmltests):
        name="HTTPS (GH_TC_4)"
        
        startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest = utilities.Utilities.startTestEnvironment(xmltests, name)

        # -------------------------------------------------------------------
        # Step 1: Clone and check that there is an expected file in the clone
        # -------------------------------------------------------------------
        
        status = utilities.Utilities.cloneRepo(xmlTest)        
        
        # -------------------------------------------------------------------
        # End of all steps - now check for the general result of the test
        # -------------------------------------------------------------------

        testsetup.TestTooling.completeTestCase(status, startTime, xmlTest)
        return status
