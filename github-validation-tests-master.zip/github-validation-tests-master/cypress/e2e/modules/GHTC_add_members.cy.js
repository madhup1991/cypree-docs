// Module declarations

import {GH_visit} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import * as constants from '../modules/Constants.cy.js';

export function GH_add_members(org, repo, team) {
	  
   // go to repository home page
   GH_visit(constants.BASEURL+'/'+org+'/'+repo);
   constants.GH_screenshot('GH_add_members (1): Repository home page');

   // go to settings tab
   GH_settings_tab();   
   constants.GH_screenshot('GH_add_members (2): Settings tab');

   // go Collaborators and teams option
   GH_settings_tab();   
   cy.contains('Collaborators and teams').should('be.visible').click();
   constants.GH_screenshot('GH_add_members (3): Access settings');
	
   // Just to be sure
   GH_visit(constants.BASEURL+'/'+org+'/'+repo+'/settings/access');
   // Select option to add a team
   cy.contains('Add teams').should('be.visible').click();
   constants.GH_screenshot('GH_add_members (4) invite teams');

   // enter team name in dialog en confirm
   cy.get('#add-team-access-dialog > .Box--overlay > .d-flex.p-4 > form.d-flex > #repo-add-access-selector > .js-repo-add-access-search-selection > auto-complete.d-block > .form-group > .js-repo-add-access-search-input').should('be.visible').type(team);
   cy.contains(team).should('be.visible').click();
   constants.GH_screenshot('GH_add_members (5): team name entered and confirmed');

   // select option for write access (3th element in permission selector)
   cy.get('#add-team-access-dialog > .Box--overlay > .d-flex.p-4 > form.d-flex > #repo-add-access-selector > .js-repo-add-access-search-selected > .Box > :nth-child(3) > .js-role-checkbox > .flex-auto > .mr-3 > input').should('be.visible').click();
   constants.GH_screenshot('GHT_add_members (6): available permissions');

   // Confirm to add team with permissions
   cy.contains('Add '+org+'/'+team).should('be.visible').click();
   constants.GH_screenshot('GHT_add_members (7): invited people and permissions');
}
