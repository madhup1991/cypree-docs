# github-validation-tests

## Description

This project contains the suite of automated test scripts which validates
Philips InnerSource GitHub SaaS environment for medical software development.
See references for more details on how you can leverage it for your
Quality Management System.

## Dependencies

- User Requirements Document (including intended use)
- Test plan
- Automated test scripts
- Test report

You can find the full list of documents and evidences in the [I2M Engineering GitHub SaaS Confluence page](https://confluence.atlas.philips.com/display/GITHUB/Validation+evidence).

## Installation

### Cypress

```
install nodejs >= 14.x
npm install cypress@6.7.1 --save-dev
npm install cypress-file-upload@5.0.2 --save-dev
npm install --save-dev mochawesome mochawesome-merge mochawesome-report-generator mocha
npm install --save-dev cypress-downloadfile
```

### Python

```
python3 -m pip install --upgrade pip
pip3 install -r requirements.txt
```

## Configuration

### Cypress

1. Setup a test validation organisation *validation-org* with a repository *workflow-validation* (to test TC31).
1. Add account *myaccount1* as owner/admin of this organization
1. Add account *myaccount2* as member of this organization 
1. Install `WORKFLOW/failing-workflow.yml` in the repository *workflow-validation* in the main branch.
1. Create a team *validationteam* in this organization and add account *myaccount1* and *myaccount2* as members of this team.
1. copy cypress.env.json-template to cypress.env.json and specify all names

### Python

Specify the following eenvironments variables:

```
GH_TOKEN   /* token for account1 to perform git commands */
ACC1       /* account1 githubvaladm */
ORG        /* organization to ceate repository to perform git tests in */
REPO       /* temporary repository to perform git tests with/in */
SUBREPO    /* temporary git repository to test git-submodules */ 
ACC1       /* account to perform git commands. Should have admin rights in the organization */
GITHUB_WORKSPACE /* in a github runner environment this variable is automatically set and pointing to the absolute path of your cloned repository for local testing this variable needs to be set */
```

## How to test the software

### Cypress

`npx cypress run|open`

### Python

`python3 scripts/basicmodule.py`

## Known issues

For known issues/improvements, check the issue in this repository: [https://github.com/philips-internal/github-validation-tests/issues](Issues). If you see issues or have suggestions for improvements, please let us know and we will submit new issue or make you collaborator of the repository.

## Daily test executions

The tests are executed daily on both Linux and Windows both on self-hoted runners on VM's hosted by IT4RND.

### Cypress

1. GH_TC_1: create repository
2. GH_TC_3: rename repository
3. GH_TC_6: add, upload, edit file using UI
4. GH_TC_7: lock/unlock a branch
6. GH_TC_9: fork a repository, create PR, merge
7. GH_TC_13: create branch rule, create branch, review, merge back
8. GH_TC_14: create branch rule, create fork,   review, merge back
9. GH_TC_31: trigger workflow manually and show results
10. GH_TC_41: create a github team
11. GH_TC_42: Check history of branch, file and folder from web UI

### Python

1. GH_TC_4: git over https
2. GH_TC_5: github workflow
3. GH_TC_8: symbolic links

## Contact / Getting help

Haenen, G.f.m. <g.f.m.haenen@philips.com>
Cullen, Robert <robert.cullen@philips.com>


You can find more information about GitHub SaaS in [I2M Engineering GitHub SaaS](https://confluence.atlas.philips.com/display/GITHUB/Validation+evidence) and [Philips InnerSource](https://confluence.atlas.philips.com/display/INNER/Innersource+Home) Confluence pages.

Information on test results, failing tests etc. you can vind here: [I2M Engineering GitHub Validation results](https://confluence.atlas.philips.com/display/GITHUB/Validation+runs)


