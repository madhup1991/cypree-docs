'''
Created on 23.03.2021

@author: dep03990
'''

import os
import lxml.etree as ET
import shutil
import sys
from datetime import datetime
import time
#import os.path
#from os import path

from tests import settings
from tests import testsetup
from tests import utilities

class WorkflowTest(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    
    @classmethod 
    def testWorkflow(cls,xmltests):
        status = True
        name="WORKFLOW (GH_TC_5)"
        
        startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest = utilities.Utilities.startTestEnvironment(xmltests, name)
        
        # create a unique branch name for thsi run
        ts = str(time.time())
        br1 = "br1_" + ts 
        
        # -------------------------------------------------------------------
        # Step 1: Clone and check that there is an expected file in the clone
        # -------------------------------------------------------------------
        
        status &= utilities.Utilities.cloneRepo(xmlTest)
        
        # -------------------------------------------------------------------
        # Step 2: Add a large file, push it, and clone again. Check if large file appears in the clone
        # -------------------------------------------------------------------
        
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        
        step2a = testsetup.TestTooling.gitcmd("checkout -b " + br1, xmlTest,"Switched to a new branch '" + br1 + "'")
        step2b = testsetup.TestTooling.gitcmd("branch -l",xmlTest,"* " + br1)
        
        stepstatus2 = step2a[0] & step2b[0]      
        status &= stepstatus2
        
        # -------------------------------------------------------------------
        # Step 3: Create a file
        # -------------------------------------------------------------------
        f = open("README.md", "a")
        # write a timestamp to the file
        ts = str(time.time())
        f.write(ts)
        f.close()
        # the check for if the file has been changed is done implicitly: if failed we have an exception here
        step3 = testsetup.TestTooling.gitcmd("add README.md",xmlTest)
        status &= step3[0]
        
        # -------------------------------------------------------------------
        # Step 4: Stash
        # -------------------------------------------------------------------
        
        step4a = testsetup.TestTooling.gitcmd("stash", xmlTest,"Saved working directory and index state WIP on " + br1)
        step4b = testsetup.TestTooling.gitcmd("stash list", xmlTest,"stash@{0}: WIP on " + br1)
        status &= step4a[0] & step4b[0]
        
        # now check that the change in README.md was reverted, i.e. the timestamp not in the file anymore
        action = "Check if file change was reverted"
        expected = "Modification in file was removed"
        isModificationRemoved = utilities.Utilities.checkForContentNotInFile("README.md", ts)
        if isModificationRemoved:
            result = "Added timestamp was removed"
            stepstatusFileCheck = True
        else:
            result = "Added filestamp was not removed"
            stepstatusFileCheck = False
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,stepstatusFileCheck)
        status &= stepstatusFileCheck
        
        step4c = testsetup.TestTooling.gitcmd("stash apply --index", xmlTest,"modified:   README.md")
        status &= step4c[0]
        
        # now check that the changes were reapplied
        action = "Check if file change was reapplied"
        expected = "Modification in file again visible"
        isModificationVisible = utilities.Utilities.checkForContentInFile("README.md", ts)
        if isModificationVisible:
            result = "Added timestamp reappeared"
            stepstatusFileCheck = True
        else:
            result = "Added filestamp still not there"
            stepstatusFileCheck = False
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,stepstatusFileCheck)
        status &= stepstatusFileCheck
        
        # -------------------------------------------------------------------
        # Step 5: Commit branch (step 9+10. in Spec)
        # -------------------------------------------------------------------
        ts = str(time.time())
        msg = "commit message at " + ts 
        step5a = testsetup.TestTooling.gitcmd("commit -m \"" + msg + "\"", xmlTest,[msg,"1 file changed"])

        # Verify the new commit is available in local repository and HEAD is pointing to this commit (Step 10 in spec)
        step5b = testsetup.TestTooling.gitcmd("log", xmlTest)
        status &= step5a[0] & step5b[0]

        # -------------------------------------------------------------------
        # Step 6: Reset and revert head
        # -------------------------------------------------------------------

        step6a = testsetup.TestTooling.gitcmd("reset --hard HEAD^", xmlTest)
        step6b = testsetup.TestTooling.gitcmd("log", xmlTest)
        step6c = testsetup.TestTooling.gitcmd("reset --hard ORIG_HEAD", xmlTest)
        status &= step6a[0] & step6b[0] & step6c[0]
        
        # -------------------------------------------------------------------
        # Step 7: Diff
        # -------------------------------------------------------------------

        step7 = testsetup.TestTooling.gitcmd("diff main.." + br1, xmlTest,"diff --git a/README.md b/README.md")
        status &= step7[0]
        
        # -------------------------------------------------------------------
        # Step 8: Push and branch (steps 15+16 in spec)
        # -------------------------------------------------------------------

        step8a = testsetup.TestTooling.gitcmd("push origin " + br1, xmlTest,"[new branch]")
        step8b = testsetup.TestTooling.gitcmd("branch -r", xmlTest,br1)
        status &= step8a[0] & step8b[0]
        
        # -------------------------------------------------------------------
        # Step 9: Create/push/delete tag (steps 17 till 21 in spec)
        # -------------------------------------------------------------------
        
        ts = str(time.time())
        tag1 = "v1.0-lw-" + ts 
        
        step9a = testsetup.TestTooling.gitcmd("tag " + tag1, xmlTest)
        step9b = testsetup.TestTooling.gitcmd("tag -l", xmlTest,tag1)
        step9c = testsetup.TestTooling.gitcmd("push origin " + tag1, xmlTest,"[new tag]")
        step9d = testsetup.TestTooling.gitcmd("tag -d " + tag1, xmlTest,"Deleted tag '" + tag1 + "'")
        # too many params!
        step9e = testsetup.TestTooling.gitcmd("push origin :" + tag1, xmlTest,"deleted")
        status &= step9a[0] & step9b[0] & step9c[0] & step9d[0] & step9e[0]

        
        # -------------------------------------------------------------------
        # Step 10: merge branch (in spec steps 22-25)
        # -------------------------------------------------------------------
        step10a = testsetup.TestTooling.gitcmd("checkout main", xmlTest,"Switched to branch 'main'")
        step10b = testsetup.TestTooling.gitcmd("branch -l", xmlTest,br1)
        step10c = testsetup.TestTooling.gitcmd("merge " + br1, xmlTest,"Fast-forward")
        step10d = testsetup.TestTooling.gitcmd("push origin main", xmlTest,"main -> main")
        status &= step10a[0] & step10b[0] & step10c[0] & step10d[0]
        
        # -------------------------------------------------------------------
        # Step 11: delete branch (steps 26-27 in spec)
        # -------------------------------------------------------------------
        step11a = testsetup.TestTooling.gitcmd("branch -d " + br1, xmlTest,"Deleted branch " + br1)
        step11b = testsetup.TestTooling.gitcmd("push origin --delete " + br1, xmlTest,"[deleted]")
        status &= step11a[0] & step11b[0]
        
        # -------------------------------------------------------------------
        # Step 12: create annotated tag (Word document steps 28-30 ff.)
        # -------------------------------------------------------------------
        
        ts = str(time.time())
        tag2 = "v2.0-" + ts 
        
        firstCommitHash = utilities.Utilities.getOutputOfCommand("git rev-list --max-parents=0 HEAD")
        step12a = testsetup.TestTooling.gitcmd("tag -a " + tag2 + " " + firstCommitHash + " -m \"version 2.0\"", xmlTest)
        step12b = testsetup.TestTooling.gitcmd("tag -l", xmlTest,tag2)
        step12c = testsetup.TestTooling.gitcmd("push origin " + tag2, xmlTest,"[new tag]")
        status &= step12a[0] & step12b[0] & step12c[0]
        
        # -------------------------------------------------------------------
        # Step 13: Verify baseline (Word document steps 31 ff.)
        # -------------------------------------------------------------------
        os.chdir(settings.Settings.WORKDIR)
        testsetup.TestTooling.doCmdWithoutCheck("mkdir tagged-" + settings.Settings.REPO)
        os.chdir("tagged-" + settings.Settings.REPO)
        utilities.Utilities.cloneRepo(xmlTest,"--branch " + tag2)
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        step13a = testsetup.TestTooling.gitcmd("log", xmlTest)
        step13b = testsetup.TestTooling.gitcmd("log -p README.md", xmlTest,'diff --git a/README.md b/README.md')
        status &= step13a[0] & step13b[0]
        
        # -------------------------------------------------------------------
        # End of all steps - now check for the general result of the test
        # -------------------------------------------------------------------
        
        testsetup.TestTooling.completeTestCase(status, startTime, xmlTest)
        return status
