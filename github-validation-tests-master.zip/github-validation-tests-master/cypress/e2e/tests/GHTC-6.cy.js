// add /edit and upload file
import * as constants from '../modules/Constants.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_code_tab} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';

describe('GitHub Version Control', () => {

   beforeEach(() => {

   GH_preserve_cookies();
   // login and create repo. Step 1 for all 6x tests
   GH_login(constants.ACC1, constants.PW1);
   constants.GH_screenshot('TC 6(ABC)-1: logged in');

   GH_delete_if_exists(constants.ORG, constants.REPO);
   GH_create_repo(constants.ORG, constants.REPO);
});

it('TC 6A: add files', () => {
  	  
       // navigate to repo
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
       constants.GH_screenshot('TC 6A-2: repository home page');
	      
       // select Code option 
       GH_code_tab();
       constants.GH_screenshot('TC 6A-3: repository code tab');
	   
       //cy.contains('Add file').click();
       //cy.contains('Create new file').click();
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO+'/new/main');
       constants.GH_screenshot('TC 6A-4: new file menu');
  
       cy.get('.js-breadcrumb-container > .form-control').type(constants.newFile);
	      
       // Enter text
       cy.get('.CodeMirror-lines').should('be.visible').type('{movetoend}Test Case run TC-6A -- '+GH_get_datetime());
    
       // Enter commit text
       cy.get('#commit-summary-input').should('be.visible').type('Changed README file for TC TC-6A '); 
    
       // Click on commit

       cy.get('#submit-file').should('be.visible').click();
	   
        constants.GH_screenshot('TC 6A-5: new file is added');

       cy.log("===> finished test 6A");

});

	
it('TC 6B: Upload files', () => {
       // navigate to repo
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
       constants.GH_screenshot('TC 6B-2: repository home page');
	  
       // select Code option 
       GH_code_tab(constants.ORG, constants.REPO);
       constants.GH_screenshot('TC 6B-3: repository code tab');
       
       //cy.get('.file-navigation').get('form > .dropdown-item');
	     
       // we can do this:
       //cy.contains('Add file').click();
       //cy.contains('Upload files').click();
	GH_visit('https://github.com/'+constants.ORG+'/'+constants.REPO+'/upload/main');   
   
       // but as a workaround   
       constants.GH_screenshot('TC 6B-4: menu to upload a file');
	     
        // start watching the POST requests
       cy.server({ method:'POST' });
       // and in particular the one with 'upload_endpoint' in the URL
       cy.route({
          method: 'POST',
          url: /upload/
       }).as('upload');

       // UPLOAD the file
       cy.get('#upload-manifest-files-input').should('be.visible').attachFile(constants.uploadFile);
	  
       // wait for the 'upload_endpoint' request, and leave a 2 minutes delay before throwing an error
       cy.wait('@upload', { requestTimeout: 12000 });

       // stop watching requests
       cy.server({ enable: false })
       constants.GH_screenshot('TC 6B-5: file to be uploaded');
	     
       // Enter commit text
       cy.get('#commit-summary-input').should('be.visible').type('Upload txt file'); 

       // Click on commit
       cy.get('button').contains('Commit').should('be.visible').click();
	   
       //GH_settings_tab();
       GH_code_tab(constants.ORG, constants.REPO);
       constants.GH_screenshot('TC 6B-6: file is uploaded');
       cy.log("===> finished test 6B");
}); 

	
it('TC 6C: edit files', () => {
	  
       // navigate to repo
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
       constants.GH_screenshot('TC 6C-2: repository home page');
 	  
       // select Code option 
       GH_code_tab();
       constants.GH_screenshot('TC 6C-3: repository code tab');
	   
       // Select the README file
       cy.contains('README.md').should('be.visible').click({force: true});
       constants.GH_screenshot('TC 6C-4: file to edit is selected');

       // Select the the pen
	GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO+'/edit/main/README.md');
       constants.GH_screenshot('TC 6C-5: edit file');
	   
       // Enter text
       cy.get('.CodeMirror').should('be.visible').type('{movetoend}Test Case run TC6C -- '+GH_get_datetime());

       // Enter commit text
       cy.get('#commit-summary-input').should('be.visible').type('Changed README file for TC6C'); 

       // Click on commit
       cy.get('#submit-file').should('be.visible').click();
       GH_code_tab();
	   
       constants.GH_screenshot('TC 6C-6: file is edited and commited');

       cy.log("===> finished test 6C");
   });
})
