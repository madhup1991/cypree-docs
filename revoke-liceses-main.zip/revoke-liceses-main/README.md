# Action to remove Dormet user 
