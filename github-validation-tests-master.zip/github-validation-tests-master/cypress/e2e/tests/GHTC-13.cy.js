// Merge PR from Branch after review 

import * as constants from '../modules/Constants.cy.js';
import { GH_add_members } from '../modules/GHTC_add_members.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import {GH_code_tab} from '../modules/utils.cy.js';
import {GH_PR_tab} from '../modules/utils.cy.js';
import {GH_branches_option} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';
import {GH_branch} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_PR} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_Merge} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_edit} from '../modules/GHTC_edit.cy.js';
import {GH_edit_and_commit} from '../modules/GHTC_edit.cy.js';
import {GH_force_reviewer} from '../modules/GHTC_lock_unlock.cy.js';

describe('GitHub Code Review', () => {

   beforeEach(() => {
      GH_preserve_cookies();
   })

   it('TC 13: code review for Branch', () => {
  	
      //==> cleanupm create repo and add team to repo

      GH_login(constants.ACC1, constants.PW1);
      constants.GH_screenshot('TC 13-1: user logged in');
	   
      GH_delete_if_exists(constants.ORG, constants.REPO);    
      GH_create_repo(constants.ORG, constants.REPO);
  
      // add whole team to repo
      GH_add_members(constants.ORG, constants.REPO, constants.VALTEAM);
	   
      //==> create a branch

      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      GH_branch(constants.BRANCH);
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO+'/edit/'+constants.BRANCH+'/README.md');
      GH_edit_and_commit(constants.ORG, constants.REPO, constants.BRANCH);

      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
	   
      // Select Branches
      GH_settings_tab();
      GH_branches_option();
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO+'/'+'settings/branches');
      constants.GH_screenshot('TC 13-8: repository branches');
	   
      // ==> Add rule to enforce reviewer

      GH_force_reviewer('main');

      //==> CREATE Pull Request: org1/repo:branch1 <- org2/repo:branch2

      // Create a pull request to pull repo back to originating repo
      GH_PR(constants.ORG, constants.ORG, constants.REPO, 'main', constants.BRANCH);

      constants.GH_screenshot('TC 13-14: Blocked pull request');    

      //==> review as account ACC2

      GH_login(constants.ACC2, constants.PW2);
      constants.GH_screenshot('TC 13-15: logged in as account2');    
	    
      // select pull request and review
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 13-16: repository home page');    
	   
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      GH_PR_tab();
      constants.GH_screenshot('TC 13-17: pull requests');    
	   
      // Open PR but make sure the PR is opened before we screenshot
      cy.contains('GHTC-PR').should('be.visible').click();
      cy.url().should('contain', '/pull/');
      cy.contains('Add your review').should('be.visible');
      constants.GH_screenshot('TC 13-18: pull request created in previous steps is selected');    
	   
      // Add review
      cy.contains('Add your review').should('be.visible').click();
      cy.contains('Review changes').should('be.visible');
      constants.GH_screenshot('TC 13-19: Add review');    
	   
      cy.contains('Review changes').should('be.visible').click();
      cy.get('#pull_request_review_body').should('be.visible').type('looks oke');
      cy.contains('Approve').should('be.visible').click();
      cy.contains('Submit review').should('be.visible').click();
      cy.url().should('include','pullrequestreview');
      constants.GH_screenshot('TC 13-20: Review submitted');    
	   
      //==> MERGE Pull request as account ACC1
	   
      GH_login(constants.ACC1, constants.PW1);
      constants.GH_screenshot('TC 13-21: Logged in with account1');    	 
	   
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 13-22: repository home page');    
	   
      GH_PR_tab();
      GH_Merge('GHTC-PR');	   
      cy.contains('GHTC-PR').should('be.visible').click();

      cy.log("===> finished test 13");

   });
})
