#!/usr/bin/env python3

import sys
import json
import os
from datetime import date
from datetime import datetime
import dateutil.parser

if len(sys.argv) != 4:
    print("This script needs 3 arguments")
    print("Usage:  "+sys.argv[0]+" <DOMAIN> <jsonfile> <datafile>")
    sys.exit(0)

TestDomain=sys.argv[1]
JsonFile=sys.argv[2]
DataFile=sys.argv[3]
separator="#"

## Format DB result:
#	[runId] -  varchar that is composed from the date & time that the JSON file with the results was generated. 
#                  This is the KEY that we use to connect to the [testResults] table to link (by SQL join) the individual test results.
#	For example, 05182022120731 represents MAY-18-2022 12:07:31
#	[runDate] - the date ant time of the JSON file created
#	[runDomain] - the domain of the automated tests.
#	For example, 'SCM-CLI-EMEA-TFVC' is the automation we have for EMEA source code CLI tests. 
#                  This automation has a dedicated pipeline that created a dedicated JSON with results and upload the JSON results to the DB.
#	For GitHub CLE tests it should be something like 'GitHub_CLI_WIN' for the CLI (not Cypress) tests running on Windows. 
#                  Please define it for each domain you have.
#	[runTotalTests] - how many tests are planned to run automatically
#	[runPassTests] - how many tests passed
#	[runFailTests] - how many tests failed
#	[runDuration] - duration of the execution in minutes
#	[upload_Date] - the date & time that the results were uploaded to the DB
#	[runResult] - Pass if all tests were passed, Failed otherwise
#	[runPassPercent] - percentage of Passed tests out of total tests
#	[runDateInString] - for us to be able to query the table, if needed.

def getepoch(d):
   str=dateutil.parser.parse(d).strftime('%d-%m-%Y %H:%M:%S,%f')
   dt_obj = datetime.strptime(str, '%d-%m-%Y %H:%M:%S,%f')
   sec = dt_obj.timestamp()
   return sec


# Opening JSON file
try:
  fj = open(JsonFile)
  data = json.loads(fj.read())
except:
  print("Error Reading Jsonfile "+JsonFile)
  sys.exit(1)

# Opening Data file
try:
  fd = open(DataFile, 'w')
except:
  print("Error Opening File "+DataFile)
  sys.exit(1)

# Iterating through the json
# list
runId = dateutil.parser.parse(data['stats']['start']).strftime('%m%d%Y%H%M%S')
output="runResultsData"+separator+runId
runDate = dateutil.parser.parse(data['stats']['start']).strftime('%b %d %Y %I:%M%p')
output=output+separator+runDate
runDomain=TestDomain
output=output+separator+runDomain
runTotalTests=str(data['stats']['tests'])
output=output+separator+runTotalTests
runPassTests=str(data['stats']['passes'])
output=output+separator+runPassTests
runFailTests=str(data['stats']['failures'])
output=output+separator+runFailTests
runDuration=str(data['stats']['duration']/1000)
output=output+separator+runDuration
now = datetime.now()
upload_Date = now.strftime("%Y-%m-%d %H:%M:%S")
output=output+separator+upload_Date
if (data['stats']['passPercent']==100):
  runResult="Pass"
else:
  runResult="Fail"
output=output+separator+runResult
runPassPercent=str(data['stats']['passPercent'])
output=output+separator+runPassPercent
#runDateInString = runId
runDateInString = now.strftime("%m/%d/%Y %H:%M:%S")
output=output+separator+runDateInString
print("#######",output)
print(output, file=fd)

for r in data['results']:
 for s in r['suites']:
   testSuiteComponent=s['title']
   for t in s['tests']:
      # [runId]
      # [testSuiteComponent] - the component we are testing. GitHub it should be: 'GitHub SCM', 'GitHub Actions'
      # [testCaseTitle] - the ID of the test case you created. ID because here we used the IDs of each test from the relevant verification spec name
      # [testName] - the name of the test case you created as in the verification spec
      # [testState] - Pass\Fail
      # [testError] - error details in case of failure
      # [testDuration]
      # [upload_Date] - the date & time that the results were uploaded to the DB

      # 20220711113404#GitHub Version Control#GitHub Version Control TC 1: create repository#TC 1: create repository#Fail#timeout#29724#20220711 14:15:24


      # [FailedAnalysis] - not required to be updated by the automation. We will use this field in the future
      output="testResults"+separator+runId
      output=output+separator+testSuiteComponent
      testCaseTitle = t['title'].split(":")[0]

      output=output+separator+testCaseTitle
      testName = t['title'].split(":")[1]
      output=output+separator+testName
      if t['pass'] == True:
         testState = 'Pass'
      else:
         testState = 'Fail'
      output=output+separator+testState
      try:
        testError=t['err']['message']
      except:
         testError=""

      testError=""
      output=output+separator+testError
      testDuration = str(round(t['duration']/1000))
      output=output+separator+testDuration
      upload_Date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
      output=output+separator+upload_Date
      output=output+separator+"NULL"
      print(">>>>>>> ",output)
      print(output, file=fd)

# Closing file
fj.close()
fd.close()
