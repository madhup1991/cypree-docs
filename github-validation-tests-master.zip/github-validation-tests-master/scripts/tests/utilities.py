'''
Created on 13.04.2021

@author: dep03990
'''

import os
import lxml.etree as ET
import shutil
import sys
import subprocess
from datetime import datetime
from tests import settings
from tests import testsetup
from fileinput import filename
from pickle import FALSE

class Utilities(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
    @classmethod
    def startTestEnvironment(cls,xmltests,name):
        xmlTest = ET.SubElement(xmltests,'test')
        xmlTest.set('name',name)
        testsetup.TestTooling.GHSetup()
        print("Change to directory " + settings.Settings.WORKDIR)
        os.chdir(settings.Settings.WORKDIR)
        # varify the path using getcwd() 
        cwd = os.getcwd() 
        # print the current directory 
        print("Current working directory is:", cwd) 
        return xmlTest
        
    @classmethod
    def getFileContent(cls,file):
        with open (file, "r") as f:
          content="----- <I/>"+file+" ----- </I/><br/>"+f.read().replace('\n','<br/>')+"<br/>-------------<br/>"
          f.close()
        return content

    @classmethod   
    def cloneRepo(cls,xmlTest,cloneArgument = ""):
        testsetup.TestTooling.gitcmd("config --global core.symlinks true ",xmlTest)
        step = testsetup.TestTooling.gitcmd("clone " + cloneArgument + " " + settings.Settings.GITCLONEURL,xmlTest,"Cloning into '" + settings.Settings.REPO + "'")
        stepstatus1 = step[0]
        
        action = "Check for content in cloned repository"
        expected = "File Readme.md could be cloned"
        if os.path.exists(settings.Settings.REPO + "/README.md"):
            result = "README.md existed in the repo"
            stepstatusLFExists = True
        else:
            result = "README.md does not exist in the repo"
            stepstatusLFExists = False
            print("Git clone failed because README.md file could not be seen in clone", file=sys.stderr)
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,stepstatusLFExists)
        return stepstatus1 & stepstatusLFExists
    
    @classmethod
    def getOutputOfCommand(cls,cmd):
        path = os.getcwd()
        print("Performing in directory '" + path + "' this command: " + cmd)
        try:
            with subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,  stderr=subprocess.STDOUT) as p:
                output, errors = p.communicate()
                lines = output.decode('utf-8')
                return lines.replace("\n","").replace("\r","")
        except:
            print ("Exception happened but can be ignored")
            return ""
        
    @classmethod
    def checkForContent(cls,haystack,needle):
        if isinstance(needle, list):
            # needle is an array. All the elements in the needle array need to be in the haystack. Otherwise False will be returned
            for aNeedle in needle:
                if aNeedle not in haystack:
                    return False
            return True
        else:
            # needle is a simple string that needs to be in the haystack to return True
            if needle in haystack:
                return True
            else:
                return False

    @classmethod
    def checkForContentInFile(cls,filename,needle):
        file1 = open(filename, 'r')
        lines = file1.readlines()

        # Strips the newline character
        for line in lines:
            if needle in line:
                return True
        return False
    
    @classmethod
    def checkForContentNotInFile(cls,filename,needle):
        if cls.checkForContentInFile(filename, needle):
            return False
        else:
            return True
