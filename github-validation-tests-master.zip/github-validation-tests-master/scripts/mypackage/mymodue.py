'''
Created on 23.03.2021

@author: dep03990
'''

class MyClass(object):
    
    TESTVAL = "123"


    def __init__(self, params):
        '''
        Constructor
        '''
        