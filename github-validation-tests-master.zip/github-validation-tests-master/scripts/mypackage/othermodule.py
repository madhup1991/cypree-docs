'''
Created on 23.03.2021

@author: dep03990
'''

from mypackage import mymodue

class MyClass(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
    def doit(self):
        mymodue.MyClass.TESTVAL