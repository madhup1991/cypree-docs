// Module declarations

import * as constants from '../modules/Constants.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import {GH_login } from '../modules/GHTC_login.cy.js';
import {GH_PR_tab} from '../modules/utils.cy.js';
import {GH_branches_option} from '../modules/utils.cy.js';

const ADDRULE='Add branch protection rule';

export function GH_lock(branch) {

      // go to settings tab
      GH_settings_tab();
      constants.GH_screenshot('GH_lock(1): settings tab');

      // Select Branches opton
      GH_branches_option();
      constants.GH_screenshot('GH_lock(2): branches overview');

      // select the option to add a rule
      
      GH_branches_option();
      cy.contains(ADDRULE).should('be.visible').click();
      constants.GH_screenshot('GH_lock(3): Add a rule');

      // add main as branch pattern
      cy.get('#rule_field').should('be.visible').type(branch);
      constants.GH_screenshot('GH_lock(4): branch name entered');

      // hit the checkbox to restrict pushing to the branches
      cy.get('#authorized_actors').should('be.visible').click();
      constants.GH_screenshot('GH_lock(5): branch lock entered');

      // create the rule
      cy.get('.js-protected-branch-settings > .btn-primary').should('be.visible').click();
      constants.GH_screenshot('GH_lock(6): branches locked overview');
}


export function GH_unlock(branch) {
      GH_settings_tab();
      constants.GH_screenshot('GH_unlock(1): settings tab');

      // Select Branches opton
      GH_branches_option();
      constants.GH_screenshot('GH_unlock(2): branches overview');

      // Verify and Delete the rule
      GH_branches_option();
      cy.contains('Delete').should('be.visible').click();
      cy.get('form > .btn-danger').should('be.visible').click();
      constants.GH_screenshot('GH_unlock(3): branches lock is removed');
}

export function GH_force_reviewer(branch) {
       GH_settings_tab();
       constants.GH_screenshot('GH_force_reviewer(1): settings tab');

       // Select Branches
       GH_branches_option();
       constants.GH_screenshot('GH_force_reviewer(2): branches');

       // ==> Add rule to enforce reviewer
       // select the option to add a rule
       cy.contains(ADDRULE).should('be.visible').click();
       constants.GH_screenshot('GH_force_reviewer(3): Add rule');

       // add main as branch pattern and hit the checkbox to restrict pushing to the branches
       cy.get('#rule_field').should('be.visible').type(branch);
       cy.get('#has_required_reviews').should('be.visible').click();

       constants.GH_screenshot('GH_force_reviewer(4): show 1 approver is required');
       cy.contains('Create').should('be.visible').click();
       constants.GH_screenshot('GH_force_reviewer(5): rule created');
}
