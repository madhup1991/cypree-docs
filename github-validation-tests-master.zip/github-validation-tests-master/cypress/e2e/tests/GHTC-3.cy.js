// Rename repository to <repo>-REMOVED and back to <repo>
import * as constants from '../modules/Constants.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import { GH_visit } from '../modules/utils.cy.js';
import { GH_settings_tab } from '../modules/utils.cy.js';
import { GH_get_datetime } from '../modules/GHTC_datetime.cy.js';

describe('GitHub Version Control', () => {
	    
   beforeEach(() => {
         GH_preserve_cookies();
   })

   it('TC 3: rename repository', () => {

      Cypress.Cookies.debug(true);
      Cypress.Cookies.defaults({
        preserve: '_device_id',
      });

     GH_login(constants.ACC1,constants.PW1);
     constants.GH_screenshot('TC 3-1: user logged in');
     GH_delete_if_exists(constants.ORG, constants.REPO);	  
     GH_delete_if_exists(constants.ORG, constants.REPO+'-RENAMED');
     GH_create_repo(constants.ORG, constants.REPO); 
	   
     // show create repository
     GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
     constants.GH_screenshot('TC 3-2: repository home page');
	   
     // rename
     GH_settings_tab();
     constants.GH_screenshot('TC 3-3: repository settings');
     cy.get('#rename-field').should('be.visible').clear();
     cy.get('#rename-field').should('be.visible').type(constants.REPO+'-RENAMED');
     cy.get('form.d-flex > .btn').should('be.visible').click();
     constants.GH_screenshot('TC 3-4: repository renamed (1)');
	   
     // rename back
     GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO+'-RENAMED');
     GH_settings_tab();
     constants.GH_screenshot('TC 3-5: repository settings tab');
     cy.get('#rename-field').should('be.visible').clear();
     cy.get('#rename-field').should('be.visible').type(constants.REPO);
     cy.get('form.d-flex > .btn').should('be.visible').click();
     constants.GH_screenshot('TC 3-6: repository after renamed back');

     cy.log("===> finished test 3");

    });
})
