// Review PR from forked repo

import * as constants from '../modules/Constants.cy.js';
import { GH_add_members } from '../modules/GHTC_add_members.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';  

import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_PR_tab} from '../modules/utils.cy.js';
import {GH_code_tab} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import {GH_branches_option} from '../modules/utils.cy.js';
import {GH_fork} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_PR} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_Merge} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_edit} from '../modules/GHTC_edit.cy.js';
import {GH_edit_and_commit} from '../modules/GHTC_edit.cy.js';
import {GH_force_reviewer} from '../modules/GHTC_lock_unlock.cy.js';

describe('GitHub Code Review', () => {

   beforeEach(() => {
        GH_preserve_cookies();
   })

   it('TC 14: code review for Fork', () => {

      //==>  cleanup and recreate repo, add team

      GH_login(constants.ACC1, constants.PW1);
      constants.GH_screenshot('TC 14-1: user logged in');

      //delete repo and old fork
      GH_delete_if_exists(constants.ORG, constants.REPO);
      GH_delete_if_exists(constants.ACC1, constants.REPO);
      GH_create_repo(constants.ORG, constants.REPO);

      GH_add_members(constants.ORG, constants.REPO, constants.VALTEAM);  	   
  
      GH_branches_option();
      constants.GH_screenshot('TC 14-6: repository branches');

      // ==> Add rule to enforce reviewer

      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      GH_force_reviewer('main');
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);

      //==> create a fork

      GH_fork(constants.ORG, constants.REPO, constants.ACC1, constants.PW1); 

      cy.reload();
      GH_visit(constants.BASEURL);
      GH_visit(constants.BASEURL+'/'+constants.ACC1+'/'+constants.REPO);
      constants.GH_screenshot('TC 14-10: Repository files in forked repo');
  
      // Edit README file in fork
      GH_edit_and_commit(constants.ACC1, constants.REPO, 'main');
	   
      //==> CREATE PR org1/repo:main <- acc1/repo:main

      // Create a pull request to pull repo back to originating repo
      GH_PR(constants.ORG, constants.ACC1, constants.REPO, 'main', 'main');
	   
      // ==> review as account ACC2

      GH_login(constants.ACC2,constants.PW2);
      constants.GH_screenshot('TC 14-18: logged with account2');
	   
      // select pull request and review
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 14-19: repository home page');

      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      GH_PR_tab();
      constants.GH_screenshot('TC 14-20: repository pull requests');
	   
      // Open PR but make sure the PR is opened
      cy.contains('GHTC-PR:').should('be.visible').click();
      cy.url().should('contain', '/pull/');
      cy.contains('Add your review').should('be.visible');
      constants.GH_screenshot('TC 14-21: select Pull request');
	   
      // pull request still blocked
      cy.contains('Add your review').should('be.visible').click();
      cy.contains('Review changes').should('be.visible');
      constants.GH_screenshot('TC 14-22: add your review');
	   
      cy.contains('Review changes').should('be.visible').click();
      cy.get('#pull_request_review_body').should('be.visible').type('looks oke');
      cy.contains('Approve').should('be.visible').click();
      cy.contains('Submit review').should('be.visible').click();
      constants.GH_screenshot('TC 14-23: Review is submitted');
	   
      //==> MERGE as ACC1
	   
      GH_login(constants.ACC1,constants.PW1);
      constants.GH_screenshot('TC 14-24: login with account1');
	   
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 14-25: repository home page');	   
	   
      // navigate to pull request
      GH_PR_tab();
      GH_Merge('GHTC-PR');
      cy.contains('GHTC-PR').should('be.visible').click();

      cy.log("===> finished test 14");
   });
})
