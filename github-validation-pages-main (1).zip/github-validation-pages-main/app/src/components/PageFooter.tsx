import * as React from "react"

export default class PageFooter extends React.Component {
    render = () =>
        <div id="footer_wrap" className="outer">
            <footer className="inner">
                <p className="copyright">github-validation-pages maintained by <a href="https://github.com/philips-internal">philips-internal</a></p>
                <p>Published with <a href="https://pages.github.com">GitHub Pages</a></p>
            </footer>
        </div>
}