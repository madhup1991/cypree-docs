# Monitoring scripts

## Git Data
`python3 basicmodule.py` will generate a json file in the reports folder \
`python3 GitJson2Data.py` wil convert the json file to a generic Data file.

## Cypress Data
`npx cypress run` will generate a json file (mochawesome.json) in the repo home page \
`python3 CypressJson2Data.py` will convert the mochawesome json report to a generic Data file.

## Upload to Database
`python3 Data2DB.py` uploads the generic generated data file to a Database

## Dataflow/process flow
```
[npx cypress run]        -> pythontests.json [GitJson2Data.py] -> Git-{OS}.csv [Data2DB.py] -> DB
[scripts/basicmodule.py] -> mochawesome.json [Git2Data.py]     -> UI-{OS}.csv  [Data2DB.py] -> DB
{OS}=Linux/Windows
```

## Data file format

### Format DB result table `runResultsData`:
```
[runId]           varchar that is composed from the date & time that the JSON file with the results was generated.
                  This is the KEY that we use to connect to the [testResults] table to link the individual test results.
                  For example, 05182022120731 represents MAY-18-2022 12:07:31
[runDate]         the date ant time of the JSON file created
[runDomain]       the domain of the automated tests.
                  For GitHub we use 'GitHub_UI_Windows' for not Cypress tests running on Windows.
                  For GitHub we use 'GitHub_Git_Windows' for not Git tests running on Windows.
                  For GitHub we use 'GitHub_UI_Linux' for not Cypress tests running on Linux.
                  For GitHub we use 'GitHub_Git_Linux' for not Git tests running on Linux.
                  Please define it for each domain you have.
[runTotalTests]   how many tests are planned to run automatically
[runPassTests]    how many tests passed
[runFailTests]    how many tests failed
[runDuration]     duration of the execution in minutes
[upload_Date]     the date & time that the results were uploaded to the DB
[runResult]       Pass if all tests were passed, Failed otherwise
[runPassPercent]  percentage of Passed tests out of total tests
[runDateInString] for us to be able to query the table, if needed.
```

### Format DB result table `testResults`:
```
[runId]                Id of RunResultsData record to which this test belongs
[testSuiteComponent]   the component we are testing. GitHub it should be: 'GitHub SCM', 'GitHub Actions'
[testCaseTitle]        the ID of the test case created. 
                       ID since here the IDs of each test from the relevant verification spec name
[testName]             the name of the test case you created as in the verification spec
[testState]            Pass\Fail
[testError]            error details in case of failure
[testDuration]         duration of test
[upload_Date]          the date & time that the results were uploaded to the DB
```
