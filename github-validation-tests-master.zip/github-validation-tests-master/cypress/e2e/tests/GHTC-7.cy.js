// Lock and unlock a branch/merge

import * as constants from '../modules/Constants.cy.js';
import { Constants } from '../modules/Constants.cy.js';
import { GH_add_members } from '../modules/GHTC_add_members.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import {GH_code_tab} from '../modules/utils.cy.js';
import {GH_branches_option} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';
import {GH_lock} from '../modules/GHTC_lock_unlock.cy.js';
import {GH_unlock} from '../modules/GHTC_lock_unlock.cy.js';
import {GH_edit} from '../modules/GHTC_edit.cy.js';
import {GH_edit_and_commit} from '../modules/GHTC_edit.cy.js';

describe('GitHub Version Control', () => {

   beforeEach(() => {

      Cypress.Cookies.debug(true);
      Cypress.Cookies.defaults({
        preserve: '_device_id',
      });
   })

   it('TC 7: lock and unlock branch', () => {

       //==> cleanup, recreate repo and add team

       GH_login(constants.ACC1, constants.PW1);
       constants.GH_screenshot('TC 7-1: logged in');
       GH_delete_if_exists(constants.ORG, constants.REPO);
       GH_create_repo(constants.ORG, constants.REPO);
	   
       // Add ACC2/valteam with write access
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
       GH_add_members(constants.ORG, constants.REPO, constants.VALTEAM);

      //==> LOCK the main branch 

      // select Settings option 
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 7-2: repository home page');
      GH_lock('main');
	   
      // Very a new rule was created on branch

      //==> TEST THE LOCK

      // login as user2   
      GH_login(constants.ACC2, constants.PW2);
      constants.GH_screenshot('TC 7-12: logged in as user 2');
	   
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 7-13: repository home page');
      GH_code_tab();
      constants.GH_screenshot('TC 7-14: repository Code');
      // select readme file

      // go to repo home page and edit readme file 
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      GH_edit(constants.ORG, constants.REPO, 'main');

      // show that the commit is blocked and the message the main branch is protected
      constants.GH_screenshot('TC 7-16: commit to protected branch is blocked');
	   
      //==> UNLOCK

      // login as ACC1 again
	   
      GH_login(constants.ACC1, constants.PW1);
      constants.GH_screenshot('TC 7-17: login with account1');
	   
      // select Settings option 
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      constants.GH_screenshot('TC 7-18: repository home page');
      GH_unlock('main')

      //==> Merge after unlocking

      // login as user2
   
      GH_login(constants.ACC2, constants.PW2);
      constants.GH_screenshot('TC 7-21: logged in with account2');
	   
      // select code
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
      GH_code_tab();
      constants.GH_screenshot('TC 7-22: repository home page');   

      // edit the README file
      GH_edit_and_commit(constants.ORG, constants.REPO, 'main');
      constants.GH_screenshot('TC 7-26: file has changed');	 	 

      cy.log("===> finished test 7");
   });
})
