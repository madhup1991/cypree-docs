import * as React from "react"
import Pill from "./Pill"
import RunResult from "../types/ResultTypes";

export default class PageHeader extends React.Component<{
    title: string,
    testResults: RunResult[] | null
}> {
    getPillText = () => {
        if (this.hasFailed())
            return "Failed";
        if (this.hasExpired())
            return "Expired";
        if (this.hasSkipped())
            return "Skipped";
        return "Passed";
    }

    addHours = (date: Date, hours: number) => {
        var copy = new Date(date.getTime());
        copy.setHours(copy.getHours() + hours);
        return copy;
    }

    hasExpired = (): boolean => {
        if (this.props.testResults === null || this.props.testResults.length === 0)
            return false;

        for (var value of this.props.testResults) {
            if (new Date() > this.addHours(new Date(value.stats.end), 24))
                return true;
        }

        return false;
    }

    hasSkipped = (): boolean => {
        if (this.props.testResults === null || this.props.testResults.length === 0)
            return false;

        for (var value of this.props.testResults) {
            if (value.stats.skipped > 0)
                return true;
        }

        return false;
    }

    hasFailed = (): boolean => {
        if (this.props.testResults === null || this.props.testResults.length === 0)
            return false;

        for (var value of this.props.testResults) {
            if (value.stats.failures > 0)
                return true;
        }

        return false;
    }

    render = () =>
        <div id="header_wrap" className="outer">
            <header className="inner">
                <a id="forkme_banner" href="https://github.com/philips-internal/github-validation-pages">View on GitHub</a>
                <h1 id="project_title"><Pill
                    skipped={this.hasSkipped()}
                    fail={this.hasFailed()}
                    warn={this.hasExpired()}>{this.getPillText()}</Pill> {this.props.title}</h1>
            </header>
        </div>;
}