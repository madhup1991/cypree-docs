import * as React from "react"
import TestSuite from "./TestSuite"
import RunResult, { SuiteResult } from "../types/ResultTypes";
import Menu from "./Menu";

export default class PageContent extends React.Component<{
    testResults: RunResult[] | null,
    testResult: RunResult | null
}> {
    getSuites = () => this.props.testResult === null ? <></> :
        this.props.testResult.results[0].suites.map((s: SuiteResult) =>
            <TestSuite key={s.title} suite={s} level={0} />);

    render = () =>
        <div id="main_content_wrap" className="outer">
            <section id="main_content" className="inner">
                <Menu testResults={this.props.testResults} testResult={this.props.testResult} />
                {this.props.testResult === null ? <></> : <h1>Test Suites</h1>}
                {this.getSuites()}
            </section>
        </div>
}