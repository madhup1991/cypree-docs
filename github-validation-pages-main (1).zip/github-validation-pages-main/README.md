# Github Validation Dashboard

The purpose of this repo is to provide an overview of the Github validation test-results. 
The repo creates a Dashboard in the repo pages URL

[Go to the Dashboard](https://ideal-umbrella-90ccd136.pages.github.io/)

The dashboard contains global test metrics and detailed information about each test as well. At different levels, Top, Test Suites and Test Cases, the chapter titles are prepadded with indicators that provide information about the state of that TestCase/TestSuites or the overall status. These indicators use text and color to indicate that tests were failed/skipped or passed.

## Publishing test results
The test results are currently produced from Cypress test-runs but in the future they may come from other sources too. 
For the Github tests there is a GitHub workflow in the actial validation tests that are scheduled every 24h. 
This cypress test-run exports it's test-results as a json file which are pushed daliy to this repo to the data folder (docs/data).

## Maintaining the Dashboard
The dashboard is written in React TypeScript and located in the [app](https://github.com/philips-internal/github-validation-pages/tree/main/app) folder. 
To install go the the app folder and run 
```
npm install
```

If you make changes in the code you need to publish them by creating a build and push it to the main branch. The sample below publishes a build in the docs folder. Note that the 'build' script has been modified to accomodate the necessary file handling (For windows specific).
```
npm run build
```

