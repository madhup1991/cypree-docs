#!/usr/bin/env python3

import sys
import pyodbc
import os
from datetime import date
from datetime import datetime
import dateutil.parser

## The script uploads a data file to MSSQL DB
## Used env vars:
##     DBSERVER name of Database server
##     DBNAME   Datanase name
##     DBUSER   useraccount
##     DBPASSWD password of DBUSER
## Calling sequence:
##    Data2DB.py <datafile>
## Format <datafile>
##   

runres="runResultsData"
testres="testResults"

if len(sys.argv) != 2:
    print("This script needs 1 argument")
    print("Usage:  "+sys.argv[0]+" <datafile>")
    sys.exit(0)

DataFile=sys.argv[1]

### test all env vara
CS_ENV_VARS = ["DBNAME", "DBSERVER", "DBUSER", "DBPASSWD"]

for var in CS_ENV_VARS:
    if var not in os.environ:
        print("Failed because ",var," is not set")
        exit(0)

DBserver=os.environ.get('DBSERVER')
DBname=os.environ.get('DBNAME')
DBuser=os.environ.get('DBUSER')
DBpasswd=os.environ.get('DBPASSWD')

print(pyodbc.drivers())

separator="#"

conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER='+DBserver+';DATABASE='+DBname+';UID='+DBuser+';PWD='+DBpasswd+';Encrypt=no;TrustServerCertificate=yes')

with open(DataFile) as fd:
  for data in fd:
    l=data.strip('\n').split(separator)
    table=l[0].strip().lower()
    print("inserting records for runId"+l[1])

    if runres.lower() == table :
       # runResultsData#09062022072120#Sep 6 2022 07:21AM#UI-Linux#12#12#0#955.51#2022-09-06 14:18:05#passwd#100#09/06/2022 14:18:05
       str="INSERT INTO "+runres+" VALUES ('"+l[1]+"', '"+l[2]+"', '"+l[3]+"', "+l[4]+", "+l[5]+", "+l[6]+", "+l[7]+",'"+l[8]+"','"+l[9]+"',"+l[10]+",'"+l[11]+"')"
       print(str)
       with conn.cursor() as curs:
          curs.execute(str)

    if testres.lower() == table :
       # testResults#09062022072120#GitHub Version Control#TC 6C# edit files#passed##40#2022-09-06 15:59:04#NULL
       str="INSERT INTO "+testres+" VALUES ('"+l[1]+"', '"+l[2]+"', '"+l[3]+"', '"+l[4]+"', '"+l[5]+"', '"+l[6]+"', "+l[7]+", '"+l[8]+"',"+l[9]+" )"
       print(str)
       with conn.cursor() as curs:
          curs.execute(str)

fd.close()
# Connect to DB

