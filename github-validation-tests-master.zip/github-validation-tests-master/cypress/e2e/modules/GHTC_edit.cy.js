// Module declarations
import * as constants from '../modules/Constants.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import {GH_login } from '../modules/GHTC_login.cy.js';
import {GH_PR_tab} from '../modules/utils.cy.js';
import {GH_code_tab} from '../modules/utils.cy.js';
import {GH_branches_option} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';

export function GH_edit(org, repo, branch) {

      GH_code_tab();
      // Select the README file
      cy.contains('README.md').should('be.visible').click({force: true});
      constants.GH_screenshot('GH_edit(1): file to edit is selected');

      // Select the the pen
      GH_visit(constants.BASEURL+'/'+org+'/'+repo+'/edit/'+branch+'/README.md', {timeout: 60000});
      //cy.get('.js-update-url-with-hash > .btn-octicon').should('be.visible').click();
      //cy.url().should('include', '/README.md');
      // cy.get('[aria-label="Edit this file"]').should('be.visible').click();
      // or just edit
      constants.GH_screenshot('GH_edit(2): edit file');

      // Enter text
      cy.get('.CodeMirror').should('be.visible').type('{movetoend} '+GH_get_datetime());

      // Enter commit text
      cy.get('#commit-summary-input').should('be.visible').type('Changed README file');
      constants.GH_screenshot('GH_edit(3): tekst entered');
      
}


export function GH_edit_and_commit(org, repo, branch) {
       GH_edit(org, repo, branch);
       // Click on commit
       cy.get('#submit-file').should('be.visible').click();
       constants.GH_screenshot('GH_edit_and_commit(1) : file is saved');
}
