// Show file history

import * as constants from '../modules/Constants.cy.js';
import { GH_add_members } from '../modules/GHTC_add_members.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';  

import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_create_team} from '../modules/GHTC_teams.cy.js';
import {GH_delete_if_exists_team} from '../modules/GHTC_teams.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';

describe('GitHub Security and Integrity', () => {

   beforeEach(() => {
       GH_preserve_cookies();
   })


   it('TC 42: Check history of branch, file and folder', () => {
	   
      GH_login(constants.ACC1, constants.PW1);
      constants.GH_screenshot('TC42-1: account logged 1');
	   
      // navigate to the repository github-validation-workflow
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF);
      constants.GH_screenshot('TC42-2: repowf homepage');
	   
      // click on branch pull down and select test-pull-request branch
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF+'/tree/'+constants.PR);
      constants.GH_screenshot('TC42-3: branch selected');
	   
      // select the commits button for the branch
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF+'/commits/'+constants.PR);
      constants.GH_screenshot('TC_42-4: overview of commit history of branch '+constants.PR);

      // navigate to the repository home page by selecting the Code tab
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF+'/tree/'+constants.PR);
      constants.GH_screenshot('TC_42-5: repository home page');
	   
      // Select the file TRIGGET-PR.md
      GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF+'/blob/'+constants.PR+'/'+constants.PRFILE);
      constants.GH_screenshot('TC_42-6: file selected');
	   
      // Select the history button
      cy.contains('History').should('be.visible').click();
      constants.GH_screenshot('TC_42-7: show history of selected file');

      cy.log("===> finished test 42");

   });
});
