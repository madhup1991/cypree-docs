import React from "react";
import RunResult from "../types/ResultTypes";
import "./MenuTile.css";
import { Link } from "react-router-dom";

export default class MenuTile extends React.Component<{
    runResult: RunResult,
    selected: boolean
}> {
    getSelectedClassName = () => this.props.selected ? " selected" : "";

    getStatusClassName = () => {
        if (this.props.runResult.stats.skipped)
            return "skip" + this.getSelectedClassName();
        if (this.props.runResult.stats.failures)
            return "fail" + this.getSelectedClassName();
        if (this.props.runResult.stats.skipped)
            return "warn" + this.getSelectedClassName();
        return "pass" + this.getSelectedClassName();
    }

    stripTimeFromDate = (date: string) => date.split("T")[0];

    render = () => <Link to={"/" + this.props.runResult.stats.title}>
        <div className={"menutile " + this.getStatusClassName()}>
            <h1 id="project_title">{this.props.runResult.stats.title}</h1>
            <table width={"100%"} cellPadding={0} cellSpacing={0}>
                <tbody>
                    <tr>
                        <td>tests</td>
                        <td>{this.props.runResult.stats.tests}</td>
                    </tr>
                    <tr>
                        <td>passes</td>
                        <td>{this.props.runResult.stats.passes}</td>
                    </tr>
                    <tr>
                        <td>failures</td>
                        <td>{this.props.runResult.stats.failures}</td>
                    </tr>
                    <tr>
                        <td>skipped</td>
                        <td>{this.props.runResult.stats.skipped}</td>
                    </tr>
                    <tr>
                        <td>Date</td>
                        <td>{this.stripTimeFromDate(this.props.runResult.stats.start.toString())}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </Link>;
}