// create github team and add users

import * as constants from '../modules/Constants.cy.js';
import { GH_add_members } from '../modules/GHTC_add_members.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_create_team } from '../modules/GHTC_teams.cy.js';  
import { GH_delete_if_exists_team } from '../modules/GHTC_teams.cy.js';  
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';

describe('GitHub Security and Integrity', () => {

   beforeEach(() => {
        GH_preserve_cookies();
   })

   it('TC 41: create team and add members', () => {
	   
      GH_login(constants.ACC1, constants.PW1);
  
      // first remove team if exists
      GH_visit(constants.BASEURL+'/orgs/'+constants.ORG+'/teams');
      GH_delete_if_exists_team(constants.ORG, constants.TMPTEAM);

      GH_visit(constants.BASEURL+'/orgs/'+constants.ORG);
      constants.GH_screenshot('TC41-1: org-team home page');

      GH_visit(constants.BASEURL+'/orgs/'+constants.ORG+'/teams');
      constants.GH_screenshot('TC41-2: team tab page');
	   
      GH_create_team(constants.ORG, constants.TMPTEAM);

      // Navigate to team members overview of team
      GH_visit(constants.BASEURL+'/orgs/'+constants.ORG+'/teams/'+constants.TMPTEAM+'/members');

      constants.GH_screenshot('TC41-6: show team members of team');

      // Click on Add member button
      cy.contains('Add a member').should('be.visible').click();
      constants.GH_screenshot('TC41-7: screen to add a member');
	   
      // fill in account useraccount2 and select the name when it is visible
      cy.get('.input-group > .auto-search-group > .form-control').should('be.visible').type(constants.ACC2);
      cy.contains(constants.ACC2).should('be.visible').click();
      constants.GH_screenshot('TC41-8: Adding account');
	   
      // click the invite button
      cy.contains('Invite').should('be.visible').click();

      constants.GH_screenshot('TC41-9: member '+constants.ACC2+' added to team '+constants.TMPTEAM);

      cy.log("===> finished test 41");
   });
});
