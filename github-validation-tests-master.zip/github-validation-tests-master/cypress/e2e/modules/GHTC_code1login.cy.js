// Module declarations
 
import * as constants from '../modules/Constants.cy.js';
export function GH_code1login(account, password) {
    //test is already logged in
	
  cy.visit(constants.BASEURL);
  cy.get('body').then(($body) => {
    if ($body.text().includes('Sign up')) {
      // yup found it
      cy.visit(constants.BASEURL+'/login');
      cy.get('#login_field').type(account);
      cy.get('#password').type(password);
      cy.get('.btn').click();
    } else{
      cy.get('.mr-0.d-none > .details-overlay > .Header-link > .dropdown-caret').click();
      cy.contains('Sign out').click({force: true});
      cy.visit(constants.BASEURL+'/login');
      cy.get('#login_field').type(account);
      cy.get('#password').type(password);
      cy.get('.btn').click();
    }
  })
}
