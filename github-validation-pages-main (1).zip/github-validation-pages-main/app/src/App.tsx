import './App.css';
import PageHeader from "./components/PageHeader"
import PageContent from "./components/PageContent"
import PageFooter from "./components/PageFooter"
import axios from "axios"
import { useState } from "react"
import RunResult from "./types/ResultTypes"
import mergeData from "./DataUtils"
import { Route, Routes, BrowserRouter } from 'react-router-dom';

export default function App() {
  const [appState, setAppState] = useState<{
    loaded: boolean,
    testResults: RunResult[] | null
  }>({
    loaded: false,
    testResults: null
  });

  function parseTitleFromUrl(url: string): string {
    return url.split("/")[1].split(".")[0];
  }

  async function loadTestResult(url: string): Promise<RunResult> {
    const res = await axios.get(url);
    const testResult = mergeData({} as RunResult, res.data as RunResult);
    testResult.stats.title = parseTitleFromUrl(url);
    return testResult;
  }

  async function loadTestResults() {
    if (!appState.loaded) {
      setAppState({
        loaded: true,
        testResults: [
          await loadTestResult("data/Github-UI-Linux.json"),
          await loadTestResult("data/Github-UI-Windows.json")
        ]
      });
    }
  }

  function renderContent(testResults: RunResult[] | null, testResult: RunResult | null) {
    return (
      <>
        <PageHeader title="Github Validation results" testResults={testResults} />
        <PageContent testResults={testResults} testResult={testResult} />
      </>);
  }

  function renderRoutes() {
    if (appState.testResults == null) return <></>;
    return (
      <BrowserRouter>
        <Routes>
          <Route path={"/"} element={renderContent(appState.testResults, null)} />
          {appState.testResults.map(t =>
            <Route path={`/${t.stats.title}`} element={renderContent(appState.testResults, t)} />
          )}
        </Routes>
      </BrowserRouter>);
  }

  loadTestResults();

  return (<>{appState.loaded && appState.testResults != null ?
    <div className="App">
      {renderRoutes()}
      <PageFooter />
    </div> : <p>Loading ...</p>}</>);
}
