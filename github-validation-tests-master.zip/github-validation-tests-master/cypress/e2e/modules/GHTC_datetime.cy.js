// Module declarations

export function GH_get_datetime() {
   var currentdate = new Date();
   var datetime = currentdate.getDay() + "/" + currentdate.getMonth()
   + "/" + currentdate.getFullYear() + " @ "
   + currentdate.getHours() + ":"
   + currentdate.getMinutes() + ":" + currentdate.getSeconds();
   return datetime;
}
