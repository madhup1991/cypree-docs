import * as React from "react"

export default class Pill extends React.Component<{
    skipped: Boolean,
    fail: Boolean,
    warn: Boolean}> {
    public static defaultProps = {
        warn: false
    };

    getClassName = () => {
        if (this.props.skipped)
            return "skip";
        if (this.props.fail)
            return "fail";
        if (this.props.warn)
            return "warn";
        return "pass"
    }

    render = () =>
        <span className={"pill " + this.getClassName()}>{this.props.children}</span>
}