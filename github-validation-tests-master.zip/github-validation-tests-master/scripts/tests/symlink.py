'''
Created on 19.04.2021

@author: dep03990
'''

import os
import shutil
import time
from datetime import datetime
import stat
import sys
from os import path
from tests import settings
from tests import testsetup
from tests import utilities

class SymlinkTest(object):
    '''
    The system shall support the use of symbolic links to more easily navigate from one place to the other within the archive.
    In this class' test method a symlimk will be created in a cloned repo. The repo is pushed back and cloned again to check
    if the symlink was successfully pushed as a symlink. The test for the file being a symlink is done by writing into the
    symlink file. 
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    @staticmethod
    def remove_readonly(func, path, excinfo):
        os.chmod(path, stat.S_IWRITE)
        func(path)
    
    @classmethod  
    def check_if_string_in_file(cls,file_name, string_to_search):
        """ Check if any line in the file contains given string """
        # Open the file in read only mode
        with open(file_name, 'r') as read_obj:
            # Read all lines in the file one by one
            for line in read_obj:
                # For each line, check if line contains the string
                if string_to_search in line:
                    return True
        return False

    @classmethod
    def checkForFileBeingSymlink(cls,xmlTest,srcfile,dstFile,dstFolder,textToAdd):
        with open(srcfile,"a") as f:
            f.write(textToAdd)

        targetFileFullPath = os.path.join(dstFolder,dstFile)
        
        action = "Check for symbolic link by looking into content of " + targetFileFullPath + " after write into " + srcfile
        expected = "Destination file was modified"
        statusOfFileWrite = cls.check_if_string_in_file(targetFileFullPath,textToAdd)
        status = True
        if statusOfFileWrite:
            result = "Target file was modified by write operation into symlink file"
            status = True
        else:
            result = "Target file was not modified by write operation into symlink file."
            return False,result
            status = False
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,statusOfFileWrite)
        print("Check for file " + srcfile + " being symlink:")
        print(status)
        return status
            
    @classmethod 
    def testSymlink(cls,xmltests):
        name="SYMLINK (GH_TC_8)"
        
        startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest = utilities.Utilities.startTestEnvironment(xmltests, name)
    
        # -------------------------------------------------------------------
        # Step 1: Clone and check that there is an expected file in the clone
        # -------------------------------------------------------------------
        
        status = utilities.Utilities.cloneRepo(xmlTest)      
        
        # -------------------------------------------------------------------
        # Step 2: Create a subdir in root directory with a file in it
        # ------------------------------------------------------------------- 
        ts = str(time.time())
        dira = "dira_" + ts
        filex = "filex_" + ts
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        os.mkdir(dira)
        with open(os.path.join(dira,"filea"), "w") as f:
            f.write("New line to test symlink")

        os.symlink(os.path.join(dira,"filea"),filex)
        
        status &= cls.checkForFileBeingSymlink(xmlTest,filex,"filea",dira,"New line to test symlink")
         
        # -------------------------------------------------------------------
        # Step 3: Check in files and symlink
        # ------------------------------------------------------------------- 
        fileapath = os.path.join(dira,"filea")
        step3a = testsetup.TestTooling.gitcmd("add " + filex + " " + fileapath, xmlTest)
        step3b = testsetup.TestTooling.gitcmd("commit -a -m \"add-symlink\"", xmlTest,"changed")
        step3c = testsetup.TestTooling.gitcmd("push origin main", xmlTest,"main -> main")
        status &= step3a[0] & step3b[0] & step3c[0]
         
        # -------------------------------------------------------------------
        # Step 4: Create empty directory in the local workspace
        # ------------------------------------------------------------------- 
        os.chdir(settings.Settings.WORKDIR)
        #ts = str(time.time())
        # rename the directory to allow a cloning again
        # os.rename(settings.Settings.REPO,settings.Settings.REPO + "-old-" + ts)
        shutil.rmtree(settings.Settings.REPO, onerror=cls.remove_readonly)
        
        if path.exists(settings.Settings.REPO):
            print("Previous clone could not be deleted", file=sys.stderr)
        print("Content in current directory:")
        os.listdir(settings.Settings.WORKDIR)
            
        # -------------------------------------------------------------------
        # Step 5: Clone again
        # ------------------------------------------------------------------- 
        print("Start cloning again to check if the symlink was correctly pushed")
        status &= utilities.Utilities.cloneRepo(xmlTest)     
        
        # -------------------------------------------------------------------
        # Step 6: Verify symbolic links
        # -------------------------------------------------------------------
        os.chdir(settings.Settings.REPO)
        
        status &= cls.checkForFileBeingSymlink(xmlTest,filex,"filea",dira,"Another new text to be added")

        
        # -------------------------------------------------------------------
        # Step 7: Check log
        # -------------------------------------------------------------------
        step7 = testsetup.TestTooling.gitcmd("log -p " + filex, xmlTest,"add-symlink") # TODO: check for content!
        status &= step7[0]
        
        # -------------------------------------------------------------------
        # End of all steps - now check for the general result of the test
        # -------------------------------------------------------------------

        testsetup.TestTooling.completeTestCase(status, startTime, xmlTest)
        return status
