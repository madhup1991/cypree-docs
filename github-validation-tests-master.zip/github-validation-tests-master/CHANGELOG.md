# Changelog

* [2021-05-18] 2.0.1  - getvars run on self-hosted instead of ubuntu-latest
* [2021-05-25] 2.0.2  - added COMMAND_DELAY (commands.js and cypress-tests*.yml
* [2021-05-25] 2.0.2  - upgrade to cypress 6.7.1
* [2021-05-25] 2.0.2  - added gh_visit before merge in GHTC-9 because of lost DOM element
* [2021-07-09] 2.0.3  - added upload artifacts to Artifactory-ehv.ta.philips.com - I2M-github-validation
* [2021-10-01] 2.0.4  - Fixed modules/add-members,js function in modules due to changed UI 
* [2021-10-01] 2.0.4  - Changes in Constants.js and importing constants and referring to constants
* [2021-10-01] 2.0.4  - Fixed tests/GHTC-9 and GHTC-14 to remove forked repo before start of tests 
* [2021-10-04] 2.0.5  - Fixed bug referring to ORG in TC-9 and clean.js due to changed Constant.js
* [2021-11-02] 2.0.6  - cleanup git repositories before git tests with REST-API instead of Cypress
* [2021-11-02] 2.0.6  - checkout non-tagged version for non-master branches (workflow yml files)
* [2021-11-05] 2.0.6  - added module submodules
* [2021-11-05] 2.0.6  - changed htmlstyle.xls to enable formatting in status column
* [2022-01-14] 2.0.7  - fixed change in Github UI manage access -> Collaborators & teams
* [2022-01-14] 2.0.7  - fixed change in Github UI manage access -> made OS order e.g. windows/linux consistent in all workflows
* [2022-01-27] 2.0.8  - fixed change in Github UI Collaborators & teams -> Collaborators and teams
* [2022-01-27] 2.0.8  - index.js fixs to resolve errr : n.subscriptions is not iterable
* [2022-01-27] 2.0.8  - Branches button new name (TC 7)
* [2022-02-07] 2.0.9  - Extracting numers of workflow runs fails due to comma separator for >= 1000 runs; removed command separator in software
* [2022-02-24] 2.0.10 - Cypress 9.3.0 and set CYPRESS_VERIFY_TINMEOUT 60000 (default 30000) to fix timeout problems
* [2022-04-11] 2.0.11 - fix for TC9 and TC14 in forking due to changed UI in the Forking menu's
* [2022-05-02] 2.0.12 - changed id's for repository tabs (settings, clone, actions, pull-requests) Added function in module utils to get/click
* [2022-05-05] 2.0.13 - TOKEN for Artifactory instead of PASSWORD
* [2022-05-12] 2.0.13 - Added TC number/name in report and log for traceability reasons on request of Roopa Jois
* [2022-06-28] 2.0.14 - verify URL for settings/actions/PR tabs
* [2022-06-28] 2.0.14 - verify PR URL changed (TC9)
* [2022-07-21] 2.0.15 - Few fixes due to timeouts (Add teams and TC-7)
* [2022-07-26] 2.0.16 - TC-31 refresh and try again in order to check if WF has completed
* [2022-08-30] 3.0.0  - many changes to meet the revised validation document (see document) for CTO OneQMS
* [2022-09-06] 3.0.1  - changed cronjob schedules
* [2022-09-06] 3.0.1  - removed uploading artifacts to github
* [2022-09-06] 3.0.1  - added scripts for dashboards
* [2022-09-13] 3.0.2  - added tools to upload results to Dashboard DB in develop version
* [2022-09-13] 3.0.2  - removed some steps in workflow file to skip in case of master branches
* [2022-10-14] 3.0.2  - removed version check and added URL check to verify correct run (GHTC-31).
* [2022-10-27] 3.0.3  - added upload of test results to DB in workflow
* [2022-11-01] 3.0.4  - Changed string "Add rule" in "Add branch protection rule"
* [2022-11-06] 3.0.5  - Fix Cookies problems related to Cypress 9.7.0
* [2022-11-21] 3.0.6  - Improved folder cleanup for git tests which fail time-to-time in Windows
* [2022-11-22] 3.0.6  - Use unique name for BASEDIR by adding timestamp, and cleanup after tests
* [2022-12-01] 3.0.7  - Added a few reloads due to changed behaviour of github
* [2022-12-06] 3.0.8  - Upgrade all tools (cypress, cypress-downloadfile, cypress-file-upload, mocha, mochawesome*) 
* [2022-12-06] 3.0.8  - Increase timeout TC31 waiting for workflow to finish
* [2022-12-06] 3.0.8  - create a switch to enable/disable SCREENSHOTS using env var (CYPRESS_SCREENSHOTS). Default=1
