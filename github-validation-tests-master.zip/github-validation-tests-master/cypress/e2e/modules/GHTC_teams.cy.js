// Module declarations
import {GH_visit} from '../modules/utils.cy.js';
import * as constants from '../modules/Constants.cy.js';
 
export function GH_delete_team(org, team) {
	
  GH_visit(constants.BASEURL+'/orgs/'+org+'/teams/'+team+'/edit');
  cy.contains('Delete this team').should('be.visible').click();
  cy.contains('I understand, delete this team').should('be.visible').click();
}

export function GH_create_team(org, team) {

      GH_visit(constants.BASEURL+'/orgs/'+org+'/teams');
      constants.GH_screenshot('GH_create team (1): Before team '+team+' is created');

      cy.contains('New team').should('be.visible').click();
      constants.GH_screenshot('GH_create team (2): new team selected ');

      cy.get('#team-name').should('be.visible').type(team);
      constants.GH_screenshot('GH_create team (3): team name entered ');
      cy.get('.js-team-privacy-closed > label').click();
      cy.contains('Create team').should('be.visible').click();

      //Click on teams URL of organization
      //an overview of available teams are displayed including team created in step 2

      GH_visit(constants.BASEURL+'/orgs/'+org+'/teams');
      constants.GH_screenshot('GH_create team (4): team created ');
 }
 

  export function GH_delete_if_exists_team(org, team) {
      // first remove team if exists
      GH_visit(constants.BASEURL+'/orgs/'+org+'/teams');

      const teamurl=constants.BASEURL+'/orgs/'+org+'/teams/'+team;
      cy.request({url: teamurl, failOnStatusCode: false}).then((response) => {
         if (response.status === 404) {
           cy.log('==> team does not exists');
         }
         else {
          cy.log('==> team does exists');
          GH_delete_team(org, team);
         }
      });
}

