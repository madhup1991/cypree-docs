'''
Created on 23.03.2021

@author: dep03990
'''

import os
import lxml.etree as ET
import shutil
from datetime import datetime
#import os.path
#from os import path

from tests import settings
from tests import testsetup
from tests import utilities

class AtomicTest(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    
    @classmethod 
    def testAtomic(cls,xmltests):
        teststatus = True
        name="ATOMIC"
        
        startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest = utilities.Utilities.startTestEnvironment(xmltests, name)
    
        # -------------------------------------------------------------------
        # Step 1: Clone and check that there is an expected file in the clone
        # -------------------------------------------------------------------
        
        teststatus &= utilities.Utilities.cloneRepo(xmlTest)
        
        # -------------------------------------------------------------------
        # Step 2: Add a large file, push it, and clone again. Check if large file appears in the clone
        # -------------------------------------------------------------------
        
        
        # next step copy a large file into the repo
        largefile = os.path.dirname(os.path.realpath(__file__)) + "/../" + settings.Settings.DATASUBDIR + "/" + settings.Settings.LARGEFILE
        shutil.copy(largefile, settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        step2a = testsetup.TestTooling.gitcmd("add " + settings.Settings.LARGEFILE,xmlTest)
        step2b = testsetup.TestTooling.gitcmd("commit -m \"Added large file\"",xmlTest,"Added large file")
        step2c= testsetup.TestTooling.gitcmd("push origin",xmlTest,"To https://")
        statusOfStep2abc = step2a[0] & step2b[0] & step2c[0]
        teststatus &= statusOfStep2abc
        
        # delete the clone - and check if a clone containts the large file (to check if the oush was successful)  
        testsetup.TestTooling.GHSetup()
        os.chdir(settings.Settings.WORKDIR)
        # clone again
        step2d = testsetup.TestTooling.gitcmd("clone " + settings.Settings.GITCLONEURL,xmlTest,"Cloning into '" + settings.Settings.REPO + "'")
        stepstatusNewClone = statusOfStep2abc & step2d[0]
        action = "Check for existence of large file in cloned repo"
        expected = "Large file is in the cloned repo"
        if os.path.exists(settings.Settings.WORKDIR + "/" + settings.Settings.REPO + "/" + settings.Settings.LARGEFILE):
            result = "Large file existed in the repo"
            stepstatusLFExists = True
        else:
            result = "Large file does not exist in the repo"
            stepstatusLFExists = False
            
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,stepstatusLFExists)
        teststatus &= stepstatusNewClone & stepstatusLFExists
        
        # -------------------------------------------------------------------
        # Step 3: Delete the file, push it.
        # -------------------------------------------------------------------

        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        step3a = testsetup.TestTooling.gitcmd("rm " + settings.Settings.LARGEFILE,xmlTest,"rm '" + settings.Settings.LARGEFILE + "'")
        step3b = testsetup.TestTooling.gitcmd("commit -m \"Removed large file\"",xmlTest,"Removed large file")
        step3c = testsetup.TestTooling.gitcmd("push origin",xmlTest,"To https://")
        stepstatus3 = step3a[0] & step3b[0] & step3c[0]
        
        # -------------------------------------------------------------------
        # End of all steps - now check for the general result of the test
        # -------------------------------------------------------------------
        teststatus &= stepstatus3
        
        testsetup.TestTooling.completeTestCase(teststatus, startTime, xmlTest)
        return teststatus
