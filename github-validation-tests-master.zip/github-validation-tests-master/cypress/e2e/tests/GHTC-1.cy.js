// Create a repository
import * as constants from '../modules/Constants.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import {GH_visit} from '../modules/utils.cy.js';

describe('GitHub Version Control', () => {

   beforeEach(() => {
         GH_preserve_cookies();
   })

   it('TC 1: create repository', () => {


      // login
      GH_login(constants.ACC1, constants.PW1);
      constants.GH_screenshot('TC 1-1: logged in');
	   
      cy.getCookie('device_id');
      GH_delete_if_exists(constants.ORG, constants.REPO);   
      // visit org home page
      GH_visit("https://github.com/"+constants.ORG);
      constants.GH_screenshot('TC 1-2: Organization home page');

      // create the repository (steps 3,4 and 5)
      GH_create_repo(constants.ORG, constants.REPO);
	   
      // show created repository in org home page
      GH_visit(constants.BASEURL+'/'+constants.ORG);
      constants.GH_screenshot('TC 1-5: after create');   
      
      cy.log("===> finished test 1");
   });
 })
