import * as React from "react"
import "./Code.css"
import SyntaxHighLighter from "react-syntax-highlighter"
import { vs2015 } from "react-syntax-highlighter/dist/esm/styles/hljs"

export default class Code extends React.Component {
    render = () => <div className="code">
        <SyntaxHighLighter language="javascript" style={vs2015}>
            {this.props.children == null ? "" : this.props.children}
        </SyntaxHighLighter>
    </div>
}