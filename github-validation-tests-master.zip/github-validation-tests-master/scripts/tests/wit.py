'''
Created on 23.03.2021

@author: dep03990
'''

import os
import lxml.etree as ET
import shutil
from datetime import datetime
#import os.path
#from os import path

from tests import settings
from tests import testsetup
from tests import utilities

class WitTest(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    
    @classmethod 
    def testWit(cls,xmltests):
        status = True
        name="WIT"
        
        startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest = utilities.Utilities.startTestEnvironment(xmltests, name)
    
        # -------------------------------------------------------------------
        # Step 1: Clone
        # -------------------------------------------------------------------
        status &= utilities.Utilities.cloneRepo(xmlTest)

        # -------------------------------------------------------------------
        # Step 2: add a line in Readme file to test link with ADS-WIT
        # -------------------------------------------------------------------
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)
        f = open("Readme.md", "a")
        f.write("New line to test ADS-WIT link")
        f.close()
        step2a = testsetup.TestTooling.gitcmd("add Readme.md",xmlTest)
        step2b = testsetup.TestTooling.gitcmd("commit -m \"Fixes AB#" + settings.Settings.WITCOMMIT + "\"",xmlTest," 1 file changed, 1 insertion")
        step2c = testsetup.TestTooling.gitcmd("push origin main",xmlTest,"Writing objects: 100%")
        status &= step2a[0] & step2b[0] & step2c[0]
        
        # -------------------------------------------------------------------
        # Step 3: CHECK link to commit in https://dev.azure.com/ADSP-Org-A02/GITHUB_CT_POC/_workitems/edit/239634
        # -------------------------------------------------------------------
        #step3a = testsetup.TestTooling.gitcmd("checkout -b mybranch",xmlTest)
        
        
        # -------------------------------------------------------------------
        # End of all steps - now check for the general result of the test
        # -------------------------------------------------------------------

        testsetup.TestTooling.completeTestCase(status, startTime, xmlTest)
        return status
    