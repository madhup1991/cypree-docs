'''
Created on 23.03.2021

@author: dep03990
'''

import os
import lxml.etree as ET
import shutil
from datetime import datetime
import time


from tests import settings
from tests import testsetup
from tests import utilities


class SubmoduleTest(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    
    @classmethod 
    def testSubmodules(cls,xmltests):
        status = True
        name="SUBMUDOLE (GH_TC_11)"
        readmeFile="README.md"
        
        startTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest = utilities.Utilities.startTestEnvironment(xmltests, name)

        # generate timestamp (for unique identification)
        ts = str(time.time())
        ts = startTime

        # -------------------------------------------------------------------
        # Step 1: Clone and check that there is an expected file in the clone
        # -------------------------------------------------------------------
        
        status &= utilities.Utilities.cloneRepo(xmlTest)
        
        # -------------------------------------------------------------------
        # Step 2: Create submodule
        # -------------------------------------------------------------------
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)

        step2 = testsetup.TestTooling.gitcmd("submodule add " + settings.Settings.GITCLONESUBURL + " " + "gitsub", xmlTest,"Cloning into")

        stepstatus2 = step2[0]
        status &= stepstatus2

        # -------------------------------------------------------------------
        # Step 3: Verify submodule
        # -------------------------------------------------------------------
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO)

        stepa = testsetup.TestTooling.gitcmd("status",xmlTest,"new file:   .gitmodules")
        stepb = testsetup.TestTooling.gitcmd("status",xmlTest,"new file:   gitsub")
        status &= stepa[0] & stepb[0]

        # -------------------------------------------------------------------
        # Step 4: Commit changes
        # -------------------------------------------------------------------

        step4 = testsetup.TestTooling.gitcmd("commit -am \"added submodule\"",xmlTest,"added submodule")
        stepstatus4 = step4[0]
        status &= stepstatus4
        
        # -------------------------------------------------------------------
        # Step 5: Verify README file of submodule and its content (should be available but not contain timestamp
        # -------------------------------------------------------------------

        
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO+"/"+"gitsub")
        isInContent = utilities.Utilities.checkForContentInFile(readmeFile, ts)

        if isInContent:
           result = readmeFile+" file does contain timestamp "+ts
           stepcontentFileCheck = False
        else:
           result = readmeFile+" file does NOT contain timestamp "+ts
           stepcontentFileCheck = True

        action = "Check for timestamp in "+readmeFile+" file in submodule"
        expected = readmeFile+" should be available but NOT contain timestamp "+ts
        result=result+"<br/>"+utilities.Utilities.getFileContent(settings.Settings.WORKDIR + "/"  + settings.Settings.REPO + "/gitsub/" + readmeFile)
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,stepcontentFileCheck)
        status &= stepcontentFileCheck

        # -------------------------------------------------------------------
        # Step 6A: Change file in local sub-modules repository 
        # -------------------------------------------------------------------
        os.chdir(settings.Settings.WORKDIR)
        stepa = testsetup.TestTooling.gitcmd("clone " + settings.Settings.GITCLONESUBURL,xmlTest,"Cloning into '" + settings.Settings.SUBREPO + "'")
        os.chdir(settings.Settings.SUBREPO)
        f = open(readmeFile, "a")
        f.write("file has changes on :"+ts+"\n")
        f.close()
        stepb = testsetup.TestTooling.gitcmd("add "+readmeFile,xmlTest)
        stepc = testsetup.TestTooling.gitcmd("commit -a -m \"changed README file\"",xmlTest,"1 file changed, 1 insertion")
        stepd = testsetup.TestTooling.gitcmd("push origin main",xmlTest,"main -> main")

        status &= stepa[0] & stepb[0] & stepc[0] & stepd[0]

        action = "Add timestamp "+ts+" in submodule"
        expected = readmeFile+" should contain timestamp "+ts+" in submodule file"
        result="<br/>"+utilities.Utilities.getFileContent(settings.Settings.WORKDIR + "/" + settings.Settings.SUBREPO + "/" + readmeFile)
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result, status)
        
        # -------------------------------------------------------------------
        # Step 7: update (pull) the validation repository which uses submodules
        # -------------------------------------------------------------------

        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO+"/"+"gitsub")
        stepa = testsetup.TestTooling.gitcmd("pull",xmlTest," 1 file changed, 1 insertion(+)")
        status &= stepa[0] 

        # -------------------------------------------------------------------
        # Step 8: Verify the changes in the readme file that must reflect the changes from step 6
        # -------------------------------------------------------------------
        # test if content does contain timestamp
        os.chdir(settings.Settings.WORKDIR + "/" + settings.Settings.REPO + "/" + "gitsub")
        isInContent = utilities.Utilities.checkForContentInFile(readmeFile, ts)

        if isInContent:
           result = readmeFile+" file contains timestamp "+ts
           stepcontentFileCheck = True
        else:
           result = readmeFile+" file does NOT contain filestamp "+ts
           stepcontentFileCheck = False

        action = "Check for content of file "+readmeFile+" in submodule"
        expected = "File "+readmeFile+" changed and should contain timestamp "+ts
        result=result+"<br/>"+utilities.Utilities.getFileContent(settings.Settings.WORKDIR + "/"  + settings.Settings.REPO + "/" + "gitsub/" + readmeFile)
        testsetup.TestTooling.addStepToXml(xmlTest,action,expected,result,stepcontentFileCheck)
        status &= stepcontentFileCheck


        # -------------------------------------------------------------------
        # End of all steps - now check for the general result of the test
        # -------------------------------------------------------------------

        testsetup.TestTooling.completeTestCase(status, startTime, xmlTest)

        return status
