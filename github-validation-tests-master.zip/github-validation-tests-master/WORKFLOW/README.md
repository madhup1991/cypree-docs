# FAILING WORKFLOW

Folder that contains workflow that will need manual trigger by GH_TC_31.
This is to prove failing workflow in case 1 job fails
