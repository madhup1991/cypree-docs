import RunResult, { TestResult, SuiteResult } from "./types/ResultTypes"

export default function mergeData(orgData: RunResult, newData: RunResult): RunResult {
    orgData.stats = newData.stats;
    orgData.results = [];

    newData.results.forEach(($outerTestResult: TestResult) => {
        let testResult = orgData.results.find(($innerTestResult: TestResult) => $outerTestResult.title === $innerTestResult.title);
        if (!testResult) {
            testResult = {} as TestResult;
            testResult.title = $outerTestResult.title;
            testResult.skipped = [];
            testResult.failures = [];
            testResult.passes = [];
            testResult.suites = [];
            orgData.results.push(testResult);
        }

        $outerTestResult.suites.forEach(($outerSuiteResult: SuiteResult) => {
            let suiteResult = testResult?.suites.find(($innerSuiteResult: SuiteResult) => $outerSuiteResult.title === $innerSuiteResult.title);
            if (!suiteResult) {
                suiteResult = {} as SuiteResult;
                suiteResult.title = $outerSuiteResult.title;
                suiteResult.skipped = [];
                suiteResult.failures = [];
                suiteResult.passes = [];
                suiteResult.suites = [];
                suiteResult.tests = [];
                testResult?.suites.push(suiteResult);
            }

            $outerSuiteResult.suites.forEach(($suiteResult: SuiteResult) => {
                $suiteResult.failures.forEach(($fail) => suiteResult?.failures.push($fail));
                $suiteResult.passes.forEach(($pass) => suiteResult?.passes.push($pass));
                $suiteResult.skipped.forEach(($skip) => suiteResult?.skipped.push($skip));
                suiteResult?.suites.push($suiteResult);
            });

            suiteResult?.failures.forEach(($fail) => testResult?.failures.push($fail));
            suiteResult?.passes.forEach(($pass) => testResult?.passes.push($pass));
            suiteResult?.skipped.forEach(($skip) => testResult?.skipped.push($skip));
        });
    });

    return orgData;
}
