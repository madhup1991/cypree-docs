
// Create a Fork 

import * as constants from '../modules/Constants.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_code_tab} from '../modules/utils.cy.js';
import {GH_PR_tab} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';
import {GH_fork} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_PR} from '../modules/GHTC_fork_branch_PR.cy.js';
import {GH_edit_and_commit} from '../modules/GHTC_edit.cy.js';

describe('GitHub Version Control', () => {

   beforeEach(() => {
      GH_preserve_cookies();
   })

   it('TC 9: fork a repository', () => {
	   
       //==> cleanup repo and fork and recreate repo
       GH_login(constants.ACC1, constants.PW1);
       constants.GH_screenshot('TC 9-1: user logged in');  

       // delete repo and fork
       GH_delete_if_exists(constants.ORG, constants.REPO);
       GH_delete_if_exists(constants.ACC1, constants.REPO);
       GH_create_repo(constants.ORG, constants.REPO);
	   
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPO);
	   
       //==> fork function
 
       GH_fork(constants.ORG, constants.REPO, constants.ACC1, constants.PW1);

       cy.reload();
       GH_visit(constants.BASEURL);

       // select Code option in the forked repo
       GH_visit(constants.BASEURL+'/'+constants.ACC1+'/'+constants.REPO);
       constants.GH_screenshot('TC 9-5: select Code in forked repository');  	  
	   
       // edit README file
       GH_edit_and_commit(constants.ACC1, constants.REPO, 'main');
       constants.GH_screenshot('TC 9-7: file is saved');  	  

       //==> CREATE PR: org/repo:main <- acc1/repo:main

       // Create a pull request to pull forked repo back to originating repo

       GH_PR(constants.ORG, constants.ACC1, constants.REPO, 'main', 'main'); 
       constants.GH_screenshot('TC 9-11: Show Pull requests');

      cy.log("===> finished test 9");
   });
})
