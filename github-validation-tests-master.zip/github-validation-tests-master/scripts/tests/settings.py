'''
Created on 23.03.2021

@author: dep03990
'''

import os
import sys
import time

class Settings(object):
    '''
    classdocs
    '''
  
    GH_USER=str(os.getenv('ACC1'))
    GH_TOKEN=str(os.getenv('GH_TOKEN'))
    ORG=str(os.getenv('ORG'))
    REPO=str(os.getenv('REPO'))
    SUBREPO=str(os.getenv('SUBREPO'))
  
    GITURL="git@github.com:" + ORG + "/" + REPO
    GITSUBURL="git@github.com:" + ORG + "/" + SUBREPO
    
    WITCOMMIT="239634"
    WITPR="239635"
    VERSION="date +%Y%m.%d.%OH.%M"
    
    LARGEFILE="large-file.tar.gz"
    ZIPFILE="images.zip"
    
    if (sys.platform == 'win32'):
        TOPDIR=r'c:\Data\GITHUB-VALIDATION'
    elif (sys.platform == 'linux'):
        TOPDIR="/tmp/GHVAL"
    else:
        print("OS not supported")

    timestr = time.strftime("%Y%m%d%H%M%S")
    BASEDIR=os.path.join(TOPDIR,"scripts") + '-' + timestr

    SOURCEDIR=os.path.join(BASEDIR,"src")
    DATADIR=os.path.join(BASEDIR,"data")
    WORKDIR=os.path.join(BASEDIR,"work")

    REPORTDIR=os.path.join(os.getenv('GITHUB_WORKSPACE'),"scripts/reporter")
    
    GITCLONEURL="https://" + GH_USER + ":" + GH_TOKEN + "@github.com/" + ORG + "/" + REPO
    GITCLONESUBURL="https://" + GH_USER + ":" + GH_TOKEN + "@github.com/" + ORG + "/" + SUBREPO
    
    DATASUBDIR = "data"
    LARGEFILE = "large-file.tar.gz"
    

    def __init__(self, params):
        '''
        Constructor
        '''
        
