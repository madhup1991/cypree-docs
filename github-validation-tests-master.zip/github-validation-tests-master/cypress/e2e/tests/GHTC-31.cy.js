import * as constants from '../modules/Constants.cy.js';
import { GH_create_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_repo } from '../modules/GHTC_create_delete.cy.js';
import { GH_delete_if_exists } from '../modules/GHTC_create_delete.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import { GH_preserve_cookies } from '../modules/GHTC_login.cy.js';
import {GH_visit} from '../modules/utils.cy.js';
import {GH_actions_tab} from '../modules/utils.cy.js';
import {GH_get_datetime} from '../modules/GHTC_datetime.cy.js';

describe('GitHub CICD orchestration', () => {

   beforeEach(() => {

      GH_preserve_cookies();
   })

   let nrtxt;
   
   it('TC 31: Workflow validation', () => {
	   
       // prepare
       GH_login(constants.ACC1,constants.PW1);	   
       constants.GH_screenshot('TC 31-1: account1 logged in');
       // show create repository
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF);
       constants.GH_screenshot('TC 31-2: Go to workflow repository');

       // go to actions tab
       GH_actions_tab();
       constants.GH_screenshot('TC 31-2: actions tab');
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF+'/actions/workflows/'+constants.WORKFLOW+'.yml');
       constants.GH_screenshot('TC 31-3: show workflow runs status and history');
	   
       // What is old nr of workflows	   
       cy.contains('workflow runs').then(($input) =>  {
       const str = $input.text().replace(/,/g, '');
       var regex = /\d+/g;
 
       var nrtxt = str.match(regex);  // creates array from matches
       cy.log('latest workflow run:'+nrtxt[0]);
		 
       cy.contains('Run workflow').should('be.visible').click();

       cy.get('[data-replace-remote-form-target=""] > [method="post"] > .btn').should('be.visible').click();
		
       // wait for new run to be started. ....

       cy.contains('workflow runs', { timeout: 50000 }).should('not.have.value', str); // wait for it to change
       cy.reload();
		 
       constants.GH_screenshot('TC 31-4: new workflow run is started');
       var nr=Number(nrtxt);
       nr++;
       var newnrtxt=nr.toString();
       cy.log('new workflow run numer: '+newnrtxt);
		 
       // go to the top most workflow run
       GH_visit(constants.BASEURL+'/'+constants.ORG+'/'+constants.REPOWF+'/actions/workflows/'+constants.WORKFLOW+'.yml');
       cy.get('.v-align-top > .h4 > .Link--primary').first().click();
	   
       // make sure this is the correct run
       var newstr='failing-workflow #'+newnrtxt;
       //cy.contains(newstr);
       cy.url().should('include', '/actions/runs');	       
       cy.log('Viewing workflow run: '+newnrtxt);

       cy.get('body').then(($body) => {
         if ($body.text().includes('Process completed', {timeout:50000} )) {
	    cy.log('completed (first time)');	 
            cy.reload()
            var success=1;
         } else {
            // reload and try again
            cy.log('lets try again');	
            cy.reload();
            cy.contains('Process completed', { timeout: 50000 });
	    cy.log('completed (second time)');	 
            cy.reload();
        }
        cy.log('==> finished processing workflow');
       })

       cy.log('and now to be sure');	
       cy.contains('Process completed', { timeout: 5000 });
       cy.reload();
	       
       cy.log('we are sure!!');	
       constants.GH_screenshot('TC 31-5: the workflow run: completed');
	       
       cy.get('.WorkflowJob-title').should('be.visible').click();
	       
       cy.get('.CheckStep-header-dropdown > .octicon').should('be.visible').click();
       constants.GH_screenshot('TC 31-6: failed workflow is selected');
	       
       cy.contains('Download log archive')
         .invoke('attr', 'href')
            .then(href => {
            cy.log(href);
            const url=constants.BASEURL+'/'+href;
            cy.downloadFile(url, 'cypress/fixtures/Download', constants.downloadFile);
            // assert file is downloaded
            cy.readFile('cypress/fixtures/Download/'+constants.downloadFile);
            constants.GH_screenshot('TC 31-7: logfile can be downloaded');
         });
      })
  });
})
