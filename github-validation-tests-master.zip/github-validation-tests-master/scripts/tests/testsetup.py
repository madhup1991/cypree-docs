'''
Created on 23.03.2021

@author: dep03990
'''
import lxml.etree as ET
from datetime import datetime
import subprocess
import shutil
import os
import sys
from os import path
import stat
from tests import settings 
from tests import utilities

class TestTooling(object):
    '''
    This class contains all methods that are of interest for execution of tests:
        - prepare a got test case by deleting data of previous test cases or runs 
        - add test result to a reporting element (XML data element)
        - perform a git command and handle the result
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
    @staticmethod
    def remove_readonly(func, path, excinfo):
        os.chmod(path, stat.S_IWRITE)
        func(path)
    
    @staticmethod    
    def addStepToXml(xmlTest,action,expected,result,status):
        execTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        test = ET.SubElement(xmlTest,'step')
        test.set('exectime',execTime)
        test.set('action',action)
        test.set('expected',expected)
        test.set('result',result)
        if status:
            test.set('status','passed')
        else:
            test.set('status','failed')
               
            
    @staticmethod    
    def gitcmd(cmd,xmlTest,expectoutput=None):
        path = os.getcwd()
        print("Performing in directory '" + path + "' this command: git " + cmd)
        try:
            #print("In reality: git clone https://gh-validation:9c59331cf4d04fd9c3c591b91666336e8b905e80@github.com/philips-internal/github-validation")
            # git clone https://gh-validation:9c59331cf4d04fd9c3c591b91666336e8b905e80@github.com/philips-internal/github-validation
            with subprocess.Popen("git " + cmd, shell=True, stdout=subprocess.PIPE,  stderr=subprocess.STDOUT) as p:
            #with subprocess.Popen("git clone https://gh-validation:9c59331cf4d04fd9c3c591b91666336e8b905e80@github.com/philips-internal/github-validation", shell=True, stdout=subprocess.PIPE,  stderr=subprocess.STDOUT) as p:
                output, errors = p.communicate()
                lines = output.decode('utf-8')
                print ("Process output: " + lines)

                if not errors:
                    print("No errors reported")
                else:
                    errorlines = errors.decode('utf-8')
                    print("Errors happened for command git " + cmd + ": " + errorlines, file=sys.stderr)
                
                # now check for the output
                if expectoutput != None:
                    # expectedoutput can be a single string or an array of strings that all need to be in the list of lines
                    if isinstance(expectoutput, list):
                        expectedAsString = ",".join(expectoutput)
                    else:
                        expectedAsString = expectoutput
                        
                    if utilities.Utilities.checkForContent(lines,expectoutput):
                        TestTooling.addStepToXml(xmlTest,"git " + cmd,"Command output contains: " + expectedAsString,lines,True)
                        return [True,lines]
                    else:
                        TestTooling.addStepToXml(xmlTest,"git " + cmd,"Command output contains: " + expectedAsString,lines,False)
                        print("Git command executed without error but expected output differs", file=sys.stderr)
                        return [False,lines,"Git command executed without error but expected output differs"]
                else:
                    # no output to check thus only return code of git command of interest
                    TestTooling.addStepToXml(xmlTest,"git " + cmd,"Command returned without error","No error or exception happened",True)
                    return [True,lines]
        except:
            print("Unexpected error:", sys.exc_info()[0])
            print("Git command executed with an exception", file=sys.stderr)
            return [False,'Git command execution resulted in an exception']
   
    @classmethod    
    def gitcmdwithoutcheck(cls,cmd):
        cls.doCmdWithoutCheck("git " + cmd)
     
    @classmethod
    def doCmdWithoutCheck(cls,cmd):
        path = os.getcwd()
        print("Performing in directory '" + path + "' this command: " + cmd)
        try:
            with subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,  stderr=subprocess.STDOUT) as p:
                output, errors = p.communicate()
                lines = output.decode('utf-8')
                print ("Process output of execution: " + lines)
        except:
            print ("Exception happened but can be ignored")
            
    @classmethod
    def completeTestCase(cls,status,startTime,xmlTest):
        if status:
            xmlTest.set('status','passed')
        else:
            xmlTest.set('status','failed') 
            
        endTime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        xmlTest.set('starttime',startTime)
        xmlTest.set('endtime',endTime) 
    
    @classmethod
    def GHcleanup(cls):

        os.chdir(settings.Settings.TOPDIR)

        if path.exists(settings.Settings.WORKDIR):
            try:
                print("Remove working directory " + settings.Settings.WORKDIR)
                shutil.rmtree(settings.Settings.WORKDIR, onerror=cls.remove_readonly)
            except OSError as e:
                print("  --> Error: %s : %s" % (settings.Settings.WORKDIR, e.strerror))

        if path.exists(settings.Settings.BASEDIR):
            try:
                print("Remove base directory " + settings.Settings.BASEDIR)
                shutil.rmtree(settings.Settings.BASEDIR)
            except OSError as e:
                print("  --> Error: %s : %s" % (settings.Settings.BASEDIR, e.strerror))


    @classmethod   
    def GHSetup(cls):
        # It may be that the current directory is the one that shall be deleted. So change to the root directory. 
    
        os.chdir(settings.Settings.TOPDIR)
        if path.exists(settings.Settings.WORKDIR):
            try:
                print("Remove working directory " + settings.Settings.WORKDIR)
                shutil.rmtree(settings.Settings.WORKDIR, onerror=cls.remove_readonly)
            except OSError as e:
                print("  --> Error: %s : %s" % (settings.Settings.WORKDIR, e.strerror))
        
        if path.exists(settings.Settings.BASEDIR):
            try:
                print("Remove base directory " + settings.Settings.BASEDIR)
                shutil.rmtree(settings.Settings.BASEDIR)
            except OSError as e:
                print("  --> Error: %s : %s" % (settings.Settings.BASEDIR, e.strerror))
            
            
        try:
            print("Create base directory " + settings.Settings.BASEDIR)
            os.mkdir(settings.Settings.BASEDIR)
        except OSError as e:
            print("Error: %s : %s" % (settings.Settings.BASEDIR, e.strerror))
            
        try:
            print("Create working directory " + settings.Settings.WORKDIR)
            os.mkdir(settings.Settings.WORKDIR)
        except OSError as e:
            print("Error: %s : %s" % (settings.Settings.WORKDIR, e.strerror))
    
        os.chdir(settings.Settings.TOPDIR)
