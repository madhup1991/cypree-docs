# How to contribute

Please submit an issue in case you want to report a bug or want to contribute a feature.
