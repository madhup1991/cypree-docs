// Module declarations

import {GH_visit} from '../modules/utils.cy.js';
import {GH_visit_wait} from '../modules/utils.cy.js';
import {GH_settings_tab} from '../modules/utils.cy.js';
import { GH_login } from '../modules/GHTC_login.cy.js';
import {GH_PR_tab} from '../modules/utils.cy.js';
import * as constants from '../modules/Constants.cy.js';


export function GH_branch(branch) {
      cy.get('#branch-select-menu > .btn').should('be.visible').click();
      cy.get('#context-commitish-filter-field').should('be.visible').type(branch);
      cy.contains('Create branch').should('be.visible').click();
      constants.GH_screenshot('GH_branch (1): branch created');
}

export function GH_fork(org, repo, acc, pw) {


       GH_visit(constants.BASEURL+org+'/'+repo);
       constants.GH_screenshot('GH_fork (1): repository home page');

       cy.contains('Fork').should('be.visible').click({timeout: 40000});
       constants.GH_screenshot('GH_fork (2): repository Fork option selected');

       // select to fork to account ("Your").
       cy.get('.js-owner-reponame > :nth-child(1)').should('be.visible').click({timeout: 40000});
       cy.get('[data-owner-settings-link-prefix="your"] > .select-menu-item-text').should('be.visible').click();

       // add description makes TC9 and TC14 less flaky
       cy.get('#fork_repository_description').should('be.visible').type('Fork for Github Validation');
       
       //== only one of the following is needed ............ TC9 however seems to want both :-(
       //cy.contains('Create fork').should('be.visible').click({timeout: 40000});
       cy.get('#fork_repository > .btn-primary').should('be.visible').click({force: true, timeout: 40000})

       constants.GH_screenshot('GH_fork (3): repository is forked');
}

export function GH_PR(org1, org2, repo, branch1, branch2) {

       //==> CREATE PR org1/repo:branch1 <- org2/repo:branch2
       // Create a pull request to pull forked repo back to originating repo
       GH_visit(constants.BASEURL+'/'+org2+'/'+repo);
       GH_PR_tab();
       constants.GH_screenshot('GH_PR (1): pull requests');

       cy.contains('New pull request').should('be.visible').click();
       constants.GH_screenshot('GH_PR (2): new pull requests');

       GH_visit(constants.BASEURL+'/'+org1+'/'+repo+'/compare/'+branch1+'...'+org2+':'+branch2);

       // Verify URL
       //cy.url().should('eq', constants.BASEURL+'/'+org1+'/'+repo+'/compare/'+branch1+'...'+org2+':'+repo+':'+branch2);
       //cy.url().should('eq', 'https://github.com/'+constants.ORG+'/'+constants.REPO+'/compare/main...'+constants.ACC1+':'+constants.REPO+':main');
       constants.GH_screenshot('GH_PR (3): specify PR repos-branches');

       // Create the pull request
       cy.contains('Create pull request').should('be.visible').click({ force: true});
       constants.GH_screenshot('GH_PR (4): PR details');

       cy.get('#pull_request_title').should('be.visible').clear();
       cy.get('#pull_request_title').should('be.visible').type('GHTC-PR: changed readme file');
       cy.get('.hx_create-pr-button').should('be.visible').click();
       constants.GH_screenshot('GH_PR (5): pull request is created');
 
       GH_PR_tab();
       constants.GH_screenshot('GH_PR (6): pull request overview');
}

export function GH_Merge(prtitle) {
      // find correct PR
      GH_PR_tab();
      constants.GH_screenshot('GH_Merge (1): pull requests ');
      cy.reload();
      cy.contains(prtitle).should('be.visible').click({timeout: 4000});
      constants.GH_screenshot('GH_Merge (2): pull request selected');

      // merge
      
      cy.contains('Merge pull request').should('be.visible').click();
      //cy.get('.BtnGroup > .btn-group-merge').should('be.visible').click();
      cy.contains('Confirm merge').should('be.visible').click({force: true});
      //cy.contains('Pull request successfully merged and closed').should('be.visible');
      cy.contains('Merged').should('be.visible');
      constants.GH_screenshot('GH_Merge (3): merged pull requests');
}
