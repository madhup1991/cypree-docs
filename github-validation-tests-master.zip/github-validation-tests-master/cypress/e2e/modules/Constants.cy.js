// Module declarations

export const ACC1 = Cypress.env('ACC1'); 
export const PW1 = Cypress.env('PW1'); 
export const ACC2 = Cypress.env('ACC2');  
export const PW2 = Cypress.env('PW2'); 
export const ORG = Cypress.env('ORG');
export const REPO = Cypress.env('REPO');
export const SUBREPO = Cypress.env('SUBREPO');
export const REPOWF = Cypress.env('REPOWF');
export const WORKFLOW=Cypress.env('WORKFLOW'); 
export const ORGVALTEAM=Cypress.env('ORG')+'/'+Cypress.env('VALTEAM');
export const VALTEAM=Cypress.env('VALTEAM');

export const BASEURL = 'https://github.com/'; 
export const TMPTEAM="tmpteam";
export const PR='test-pull-request';
export const PRFILE='TRIGGERS-PR.md';

export const BRANCH = 'branch1';

export const uploadFile='upload.txt';
export const newFile='newfile.txt';

export const downloadFile='workflow-run-download.zip';

export const REPOFILE='README.md';

const SCREENSHOTS=Cypress.env('SCREENSHOTS');
export function GH_screenshot(text) {
    if (SCREENSHOTS != 0) cy.screenshot(text);
}

