const { defineConfig } = require('cypress')

module.exports = defineConfig({
  viewportWidth: 1200,
  viewportHeight: 1400,
  defaultCommandTimeout: 20000,
  pageLoadTimeout: 200000,
  chromeWebSecurity: false,
  video: false,
  reporter: 'mochawesome',
  retries: {
    runMode: 2,
    openMode: 0,
  },
  reporterOptions: {
    reportDir: 'cypress/results',
    overwrite: false,
    ' html': false,
    json: true,
  },
  e2e: {
    // We've imported your old cypress plugins here.
    // You may want to clean this up later by importing these.
    setupNodeEvents(on, config) {
      return require('./cypress/plugins/index.js')(on, config)
    },
    baseUrl: 'https://github.com',
  },
})
