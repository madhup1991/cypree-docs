export type StatsResult = {
    title: string,
    suites: number,
    tests: number,
    passes: number,
    pending: number,
    failures: number,
    start: Date,
    end: Date,
    duration: number,
    testsRegistered: number,
    passPercent: number,
    pendingPercent: number,
    other: number,
    hasOther: boolean,
    skipped: number,
    hasSkipped: boolean
}

export type TestCaseResult = {
    uuid: string,
    title: string,
    fullTitle: string,
    duration: number,
    state: string,
    speed: string,
    pass: boolean,
    fail: boolean,
    pending: boolean,
    code: string,
    skipped: boolean,
    timedOut: any
}

export type SuiteResult = {
    title: string,
    skipped: string[],
    failures: string[],
    passes: string[],
    suites: SuiteResult[],
    tests: TestCaseResult[]
}

export type TestResult = {
    title: string,
    skipped: string[],
    failures: string[],
    passes: string[],
    suites: SuiteResult[]
}

type RunResult = {
    stats: StatsResult;
    results: TestResult[];
}

export default RunResult;