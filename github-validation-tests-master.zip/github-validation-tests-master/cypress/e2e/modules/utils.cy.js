import * as constants from '../modules/Constants.cy.js';

export function GH_get(element) {
  cy.get(element).should('be.visible').click();
}

export function GH_contains(text) {
  cy.contains(text).should('be.visible').click();
}

function wait(ms){
   var start = new Date().getTime();
   var end = start;
   while(end < start + ms) {
     end = new Date().getTime();
  }
}

export function GH_visit(url) {
    cy.visit(url,{retryOnStatusCodeFailure:true, timeout: 600000});
}

export function GH_visit_wait(gurl) {
    cy.log('==> visiting '+gurl);
    cy.request({url: gurl, failOnStatusCode: false, timeout: 60000}).then((response) => {
      if (response.status === 404) {
            wait(10000);
            cy.reload();
            cy.visit(gurl,{retryOnStatusCodeFailure:true, timeout: 60000});
      }
      else {
          cy.log('==> seems fine');
      }
    });
}

export function GH_settings_tab(org, repo) {

    org = org || constants.ORG; 
    repo = repo || constants.REPO; 

  //** go directly to URL or click on settings, either way, let's wait for the URL to be fine

  GH_visit(constants.BASEURL + org + "/" + repo + "/settings");
  //cy.get('#settings-tab').should('be.visible').click();

  cy.url().should('include', '/settings');
}

export function GH_code_tab(org, repo) {

    org = org || constants.ORG;
    repo = repo || constants.REPO;

  //** go directly to URL or click on tab, either way, let's wait for the URL to be fine

  GH_visit(constants.BASEURL + "/"+ constants.ORG + "/" + constants.REPO);

  //cy.get('#code-tab').should('be.visible').click();
}

export function GH_PR_tab(org, repo) {

    org = org || constants.ORG;
    repo = repo || constants.REPO;

  //** go directly to URL or click on tab, either way, let's wait for the URL to be fine

  //GH_visit(constants.BASEURL + "/"+ constants.ORG + "/" + constants.REPO + "/pulls");
  cy.reload();
  cy.get('#pull-requests-tab').should('be.visible').click();
  cy.url().should('include', '/pulls');
}

export function GH_actions_tab(org, repo) {

    org = org || constants.ORG;
    repo = repo || constants.REPO;

  //** go directly to URL or click on tab, either way, let's wait for the URL to be fine

  //GH_visit(constants.BASEURL + "/"+ constants.ORG + "/" + constants.REPO + "/actions");

  cy.get('#actions-tab').should('be.visible').click();
  cy.url().should('include', '/actions');
}

export function GH_branches_option(org, repo) {

    org = org || constants.ORG;
    repo = repo || constants.REPO;

  //** go directly to URL or click on branch, either way, lets wait for the URL to be correct

  GH_visit(constants.BASEURL + "/"+ constants.ORG + "/" + constants.REPO + "/settings/branches");

  //cy.get('[data-item-id="repo_branch_settings"]').should('be.visible').click();

  cy.url().should('include', '/branches');
}
